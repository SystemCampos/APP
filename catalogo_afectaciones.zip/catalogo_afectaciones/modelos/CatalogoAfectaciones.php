<?php
require "../config/conexion.php";
require_once "../funcionesGlobales/catalogo_afectaciones.php";

class CatalogoAfectaciones {
    private $idempresa;
    private $usaDescCorta;

    public function __construct(){
        $this->idempresa = isset($_COOKIE['id']) ? (int)$_COOKIE['id'] : 0;
        $this->usaDescCorta = caf_columna_existe('catalogo_afectaciones_sunat', 'descripcion_corta');
        if($this->idempresa > 0){
            caf_ensure_catalogo_empresa($this->idempresa);
        }
    }

    private function codigoValido($codigo){
        return in_array((string)$codigo, caf_codigos_validos(), true);
    }

    private function tributoValido($codTrib){
        return in_array(trim((string)$codTrib), array('1000','9996','9997','9998'), true);
    }

    private function obtenerPorId($id){
        $id = (int)$id;
        if($id <= 0){ return array(); }
        try{
            $sql = "SELECT * FROM catalogo_afectaciones_sunat WHERE id='".$id."' AND idempresa='".$this->idempresa."' LIMIT 1";
            $row = ejecutarConsultaSimpleFila($sql);
            return is_array($row) ? $row : array();
        }catch(Exception $e){
            return array();
        }
    }

    private function resolverCodigo($codigo, $id=0){
        $codigoNorm = caf_extraer_codigo($codigo, '');
        if($codigoNorm !== '' && $this->codigoValido($codigoNorm)){
            return $codigoNorm;
        }

        $row = $this->obtenerPorId($id);
        if($row && isset($row['codigo'])){
            $codigoNorm = caf_extraer_codigo($row['codigo'], '');
            if($codigoNorm !== '' && $this->codigoValido($codigoNorm)){
                return $codigoNorm;
            }
        }

        return '';
    }

    private function porcentajeNormalizado($codigo, $porcentaje){
        $codigo = caf_tipo_to_codigo($codigo);
        $def = caf_get_codigo_conf($codigo, $this->idempresa);
        $pct = number_format((float)$porcentaje, 2, '.', '');

        if(in_array($codigo, array('20','21','30','31','32','33','34','35','36'), true)){
            return '0.00';
        }

        if((float)$pct <= 0){
            return isset($def['porcentaje_igv'])
                ? number_format((float)$def['porcentaje_igv'], 2, '.', '')
                : caf_tasa_default_empresa($this->idempresa);
        }

        return $pct;
    }

    private function descripcionCortaNormalizada($codigo, $descripcion, $descripcion_corta){
        $descripcion = trim((string)$descripcion);
        $descripcion_corta = trim((string)$descripcion_corta);

        if($descripcion_corta === ''){
            $descripcion_corta = caf_descripcion_corta_default($codigo, $this->idempresa);
        }
        if($descripcion_corta === ''){
            $descripcion_corta = $descripcion;
        }

        return limpiarCadena($descripcion_corta);
    }

    public function insertar($codigo, $descripcion, $descripcion_corta, $cod_tributo, $porcentaje_igv, $orden){
        $codigo = $this->resolverCodigo($codigo, 0);
        $descripcion = trim((string)$descripcion);
        $cod_tributo = trim((string)$cod_tributo);
        $orden = (int)$orden;

        if(!$this->codigoValido($codigo)){ return 'CODIGO_INVALIDO'; }
        if(!$this->tributoValido($cod_tributo)){ return 'TRIBUTO_INVALIDO'; }
        if($descripcion === ''){ return 'DESCRIPCION_REQUERIDA'; }

        $porcentaje_igv = $this->porcentajeNormalizado($codigo, $porcentaje_igv);
        $descripcion = limpiarCadena($descripcion);
        $descripcion_corta = $this->descripcionCortaNormalizada($codigo, $descripcion, $descripcion_corta);

        $row = ejecutarConsultaSimpleFila("SELECT id FROM catalogo_afectaciones_sunat WHERE idempresa='".$this->idempresa."' AND codigo='".$codigo."' LIMIT 1");
        if($row && isset($row['id']) && (int)$row['id'] > 0){ return 'DUPLICADO'; }

        if($this->usaDescCorta){
            $sql = "INSERT INTO catalogo_afectaciones_sunat (idempresa,codigo,descripcion,descripcion_corta,cod_tributo,porcentaje_igv,orden,estado)
                    VALUES ('".$this->idempresa."','".$codigo."','".$descripcion."','".$descripcion_corta."','".$cod_tributo."','".$porcentaje_igv."','".$orden."','1')";
        }else{
            $sql = "INSERT INTO catalogo_afectaciones_sunat (idempresa,codigo,descripcion,cod_tributo,porcentaje_igv,orden,estado)
                    VALUES ('".$this->idempresa."','".$codigo."','".$descripcion."','".$cod_tributo."','".$porcentaje_igv."','".$orden."','1')";
        }

        return ejecutarConsulta($sql);
    }

    public function editar($id, $codigo, $descripcion, $descripcion_corta, $cod_tributo, $porcentaje_igv, $orden){
        $id = (int)$id;
        $codigo = $this->resolverCodigo($codigo, $id);
        $descripcion = trim((string)$descripcion);
        $cod_tributo = trim((string)$cod_tributo);
        $orden = (int)$orden;

        if($id <= 0){ return 'ID_INVALIDO'; }
        if(!$this->codigoValido($codigo)){ return 'CODIGO_INVALIDO'; }
        if(!$this->tributoValido($cod_tributo)){ return 'TRIBUTO_INVALIDO'; }
        if($descripcion === ''){ return 'DESCRIPCION_REQUERIDA'; }

        $porcentaje_igv = $this->porcentajeNormalizado($codigo, $porcentaje_igv);
        $descripcion = limpiarCadena($descripcion);
        $descripcion_corta = $this->descripcionCortaNormalizada($codigo, $descripcion, $descripcion_corta);

        $row = ejecutarConsultaSimpleFila("SELECT id FROM catalogo_afectaciones_sunat WHERE idempresa='".$this->idempresa."' AND codigo='".$codigo."' AND id<>'".$id."' LIMIT 1");
        if($row && isset($row['id']) && (int)$row['id'] > 0){ return 'DUPLICADO'; }

        if($this->usaDescCorta){
            $sql = "UPDATE catalogo_afectaciones_sunat
                    SET codigo='".$codigo."',
                        descripcion='".$descripcion."',
                        descripcion_corta='".$descripcion_corta."',
                        cod_tributo='".$cod_tributo."',
                        porcentaje_igv='".$porcentaje_igv."',
                        orden='".$orden."'
                    WHERE id='".$id."' AND idempresa='".$this->idempresa."'";
        }else{
            $sql = "UPDATE catalogo_afectaciones_sunat
                    SET codigo='".$codigo."',
                        descripcion='".$descripcion."',
                        cod_tributo='".$cod_tributo."',
                        porcentaje_igv='".$porcentaje_igv."',
                        orden='".$orden."'
                    WHERE id='".$id."' AND idempresa='".$this->idempresa."'";
        }

        return ejecutarConsulta($sql);
    }

    public function desactivar($id){
        $id = (int)$id;
        return ejecutarConsulta("UPDATE catalogo_afectaciones_sunat SET estado='0' WHERE id='".$id."' AND idempresa='".$this->idempresa."'");
    }

    public function activar($id){
        $id = (int)$id;
        return ejecutarConsulta("UPDATE catalogo_afectaciones_sunat SET estado='1' WHERE id='".$id."' AND idempresa='".$this->idempresa."'");
    }

    public function mostrar($id){
        $row = $this->obtenerPorId($id);
        if($row && !isset($row['descripcion_corta'])){
            $row['descripcion_corta'] = caf_descripcion_corta_default(isset($row['codigo']) ? $row['codigo'] : '10', $this->idempresa);
        }
        return $row;
    }

    public function listar(){
        caf_ensure_catalogo_empresa($this->idempresa);
        $cols = "id,idempresa,codigo,descripcion,".($this->usaDescCorta ? "descripcion_corta," : "'' AS descripcion_corta,")."cod_tributo,porcentaje_igv,orden,estado";
        $sql = "SELECT ".$cols." FROM catalogo_afectaciones_sunat WHERE idempresa='".$this->idempresa."' ORDER BY orden ASC, codigo ASC";
        return ejecutarConsulta($sql);
    }

    public function selectActivos(){
        caf_ensure_catalogo_empresa($this->idempresa);
        $cols = "id,idempresa,codigo,descripcion,".($this->usaDescCorta ? "descripcion_corta," : "'' AS descripcion_corta,")."cod_tributo,porcentaje_igv,orden,estado";
        $sql = "SELECT ".$cols." FROM catalogo_afectaciones_sunat WHERE idempresa='".$this->idempresa."' AND estado='1' ORDER BY orden ASC, codigo ASC";
        return ejecutarConsulta($sql);
    }
}
?>
