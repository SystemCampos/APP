<?php
require 'config/conexion.php';
require_once 'funcionesGlobales/catalogo_afectaciones.php';
if(!isset($_COOKIE['configuracion']) || $_COOKIE['configuracion']==0){
    header('Location: escritorio.php');
    exit;
}
$idempresa = isset($_COOKIE['id']) ? (int)$_COOKIE['id'] : 0;
caf_ensure_catalogo_empresa($idempresa);
?>
<!DOCTYPE html>
<html lang="es">
<head><?php require 'includes/header.php'; ?></head>
<body class="page-body page-fade" data-url="http://neon.dev">
<?php require 'includes/sup.php'; ?>

<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-primary" id="panelCatalogoAfectaciones">
            <div class="panel-heading">
                <div class="panel-title">Catálogo Afectaciones SUNAT</div>
            </div>
            <div class="panel-body">
                <form id="formCatalogoAfectaciones" method="POST">
                    <input type="hidden" name="id" id="id" value="0">
                    <div class="row">
                        <div class="form-group col-lg-2 col-md-3 col-sm-6 col-xs-12">
                            <label>Código</label>
                            <select name="codigo" id="codigo" class="form-control" required>
                                <?= caf_options_html('10', $idempresa, false); ?>
                            </select>
                        </div>
                        <div class="form-group col-lg-4 col-md-5 col-sm-6 col-xs-12">
                            <label>Descripción</label>
                            <input type="text" name="descripcion" id="descripcion" class="form-control" maxlength="255" required>
                        </div>
                        <div class="form-group col-lg-2 col-md-4 col-sm-6 col-xs-12">
                            <label>Descripción corta</label>
                            <input type="text" name="descripcion_corta" id="descripcion_corta" class="form-control" maxlength="120" placeholder="Ej.: Gravado Onerosa">
                        </div>
                        <div class="form-group col-lg-1 col-md-3 col-sm-6 col-xs-12">
                            <label>Tributo</label>
                            <select name="cod_tributo" id="cod_tributo" class="form-control" required>
                                <option value="1000">1000</option>
                                <option value="9996">9996</option>
                                <option value="9997">9997</option>
                                <option value="9998">9998</option>
                            </select>
                        </div>
                        <div class="form-group col-lg-1 col-md-3 col-sm-6 col-xs-12">
                            <label>% IGV</label>
                            <input type="number" step="0.01" min="0" name="porcentaje_igv" id="porcentaje_igv" class="form-control" value="18.00" required>
                        </div>
                        <div class="form-group col-lg-1 col-md-3 col-sm-6 col-xs-12">
                            <label>Orden</label>
                            <input type="number" min="0" name="orden" id="orden" class="form-control" value="10" required>
                        </div>
                        <div class="form-group col-lg-1 col-md-3 col-sm-12 col-xs-12">
                            <label>&nbsp;</label>
                            <div>
                                <button type="submit" id="btnGuardarCatalogo" class="btn btn-primary btn-block">Guardar</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <button type="button" class="btn btn-default" onclick="limpiarCatalogoAfectaciones()"><i class="fa fa-eraser"></i> Limpiar</button>
                            <span class="help-block" style="margin-top:10px;">
                                La descripción corta sirve para combos y reportes breves. Para códigos exonerados o inafectos el porcentaje se fija en 0.00.
                            </span>
                        </div>
                    </div>
                </form>
                <hr>
                <div class="table-responsive">
                    <table id="tbllistado_catalogo_afectaciones" class="table table-bordered table-striped table-responsive display nowrap" width="100%" cellspacing="0">
                        <thead>
                            <th>Opciones</th>
                            <th>Código</th>
                            <th>Descripción</th>
                            <th>Descripción corta</th>
                            <th>Tributo</th>
                            <th>% IGV</th>
                            <th>Orden</th>
                            <th>Estado</th>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'includes/pie.php'; ?>
<script src="scripts/catalogo-afectaciones.js?v=11"></script>
</body>
</html>
