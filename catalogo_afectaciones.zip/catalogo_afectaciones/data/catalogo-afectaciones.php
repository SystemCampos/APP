<?php
require_once "../modelos/CatalogoAfectaciones.php";
require_once "../funcionesGlobales/catalogo_afectaciones.php";

$modelo = new CatalogoAfectaciones();

$id = isset($_POST['id']) ? limpiarCadena($_POST['id']) : (isset($_GET['id']) ? limpiarCadena($_GET['id']) : '0');
$codigo = isset($_POST['codigo']) ? limpiarCadena($_POST['codigo']) : '';
$descripcion = isset($_POST['descripcion']) ? limpiarCadena($_POST['descripcion']) : '';
$descripcion_corta = isset($_POST['descripcion_corta']) ? limpiarCadena($_POST['descripcion_corta']) : '';
$cod_tributo = isset($_POST['cod_tributo']) ? limpiarCadena($_POST['cod_tributo']) : '';
$porcentaje_igv = isset($_POST['porcentaje_igv']) ? limpiarCadena($_POST['porcentaje_igv']) : '0.00';
$orden = isset($_POST['orden']) ? limpiarCadena($_POST['orden']) : '0';

function _msg_catalogo($r, $okInsert, $okUpdate){
    if($r === 'DUPLICADO') return 'Ya existe ese código en el catálogo';
    if($r === 'CODIGO_INVALIDO') return 'Código SUNAT inválido';
    if($r === 'TRIBUTO_INVALIDO') return 'Código de tributo inválido';
    if($r === 'DESCRIPCION_REQUERIDA') return 'Ingrese descripción';
    if($r === 'ID_INVALIDO') return 'ID inválido';
    if($r === true) return $okInsert ? 'Registro guardado' : $okUpdate;
    return 'No se pudo guardar';
}

$op = isset($_GET['op']) ? $_GET['op'] : '';

switch($op){
    case 'guardaryeditar':
        if(empty($id) || $id === '0'){
            $rspta = $modelo->insertar($codigo, $descripcion, $descripcion_corta, $cod_tributo, $porcentaje_igv, $orden);
            echo ($rspta === true) ? 'Registro guardado' : _msg_catalogo($rspta, true, 'Registro actualizado');
        }else{
            $rspta = $modelo->editar($id, $codigo, $descripcion, $descripcion_corta, $cod_tributo, $porcentaje_igv, $orden);
            echo ($rspta === true) ? 'Registro actualizado' : _msg_catalogo($rspta, true, 'Registro actualizado');
        }
    break;

    case 'desactivar':
        $rspta = $modelo->desactivar($id);
        echo $rspta ? 'Registro desactivado' : 'No se pudo desactivar';
    break;

    case 'activar':
        $rspta = $modelo->activar($id);
        echo $rspta ? 'Registro activado' : 'No se pudo activar';
    break;

    case 'mostrar':
        $rspta = $modelo->mostrar($id);
        echo json_encode($rspta);
    break;

    case 'listar':
        $rspta = $modelo->listar();
        $data = array();

        while($reg = $rspta->fetch_object()){
            $data[] = array(
                '0' => ((string)$reg->estado === '1'
                    ? '<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->id.')"><i class="fa fa-pencil"></i></button> <button class="btn btn-danger btn-xs" onclick="desactivar('.$reg->id.')"><i class="fa fa-close"></i></button>'
                    : '<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->id.')"><i class="fa fa-pencil"></i></button> <button class="btn btn-primary btn-xs" onclick="activar('.$reg->id.')"><i class="fa fa-check"></i></button>'),
                '1' => $reg->codigo,
                '2' => $reg->descripcion,
                '3' => isset($reg->descripcion_corta) ? $reg->descripcion_corta : '',
                '4' => $reg->cod_tributo,
                '5' => number_format((float)$reg->porcentaje_igv, 2, '.', ''),
                '6' => (int)$reg->orden,
                '7' => ((string)$reg->estado === '1') ? '<div class="label label-success">Activado</div>' : '<div class="label label-default">Desactivado</div>'
            );
        }

        $results = array(
            'sEcho'=>1,
            'iTotalRecords'=>count($data),
            'iTotalDisplayRecords'=>count($data),
            'aaData'=>$data
        );
        echo json_encode($results);
    break;

    case 'select':
        $idempresa = isset($_COOKIE['id']) ? (int)$_COOKIE['id'] : 0;
        echo json_encode(caf_catalogo_js_activo($idempresa));
    break;
}
?>
