-- PATCH: catálogo de afectaciones SUNAT por empresa
CREATE TABLE IF NOT EXISTS `catalogo_afectaciones_sunat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idempresa` int(11) NOT NULL,
  `codigo` varchar(2) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `descripcion_corta` varchar(120) NOT NULL DEFAULT '',
  `cod_tributo` varchar(4) NOT NULL,
  `porcentaje_igv` decimal(5,2) NOT NULL DEFAULT 0.00,
  `orden` int(11) NOT NULL DEFAULT 0,
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_catalogo_afectaciones_empresa_codigo` (`idempresa`,`codigo`),
  KEY `idx_catalogo_afectaciones_empresa_estado` (`idempresa`,`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

ALTER TABLE `catalogo_afectaciones_sunat`
  ADD COLUMN IF NOT EXISTS `descripcion_corta` varchar(120) NOT NULL DEFAULT '' AFTER `descripcion`;

UPDATE `catalogo_afectaciones_sunat`
SET `descripcion_corta` = CASE `codigo`
  WHEN '10' THEN 'Gravado Onerosa'
  WHEN '11' THEN 'Gravado Premio'
  WHEN '12' THEN 'Gravado Donación'
  WHEN '13' THEN 'Gravado Retiro'
  WHEN '14' THEN 'Gravado Publicidad'
  WHEN '15' THEN 'Gravado Bonificación'
  WHEN '16' THEN 'Gravado Trabajadores'
  WHEN '20' THEN 'Exonerado Onerosa'
  WHEN '21' THEN 'Exonerado Gratuita'
  WHEN '30' THEN 'Inafecto Onerosa'
  WHEN '31' THEN 'Inafecto Bonificación'
  WHEN '32' THEN 'Inafecto Retiro'
  WHEN '33' THEN 'Inafecto Muestra médica'
  WHEN '34' THEN 'Inafecto Convenio colectivo'
  WHEN '35' THEN 'Inafecto Premio'
  WHEN '36' THEN 'Inafecto Publicidad'
  ELSE `descripcion`
END
WHERE TRIM(IFNULL(`descripcion_corta`, '')) = '';
