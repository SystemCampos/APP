Archivos corregidos del ciclo completo de catálogo de afectaciones SUNAT.

Aplicar/reemplazar:
- catalogo-afectaciones.php
- data/catalogo-afectaciones.php
- funcionesGlobales/catalogo_afectaciones.php
- modelos/CatalogoAfectaciones.php
- scripts/catalogo-afectaciones.js

Si la tabla no tiene descripcion_corta, ejecutar:
- DB/patch_catalogo_afectaciones_sunat.sql
