var tablaCatalogoAfectaciones;

function codigoCatalogoRespaldo(){
    return String($('#formCatalogoAfectaciones').data('codigo-original') || '').trim();
}

function extraerCodigoDesdeTextoCatalogo(valor){
    valor = String(valor || '').trim();
    if(valor === ''){ return ''; }

    var m = valor.match(/(?:^|[^0-9])(10|11|12|13|14|15|16|20|21|30|31|32|33|34|35|36)(?:[^0-9]|$)/);
    return m ? m[1] : '';
}

function codigoCatalogoActual(){
    var $sel = $('#codigo');
    var $opt = $sel.find('option:selected');

    var candidatos = [
        $sel.val(),
        $opt.val(),
        $opt.data('codigo'),
        $opt.attr('data-codigo'),
        $opt.text()
    ];

    for(var i=0; i<candidatos.length; i++){
        var cod = extraerCodigoDesdeTextoCatalogo(candidatos[i]);
        if(cod !== ''){ return cod; }
    }

    return '';
}

function seleccionarCodigoCatalogo(codigo){
    codigo = String(codigo || '').trim();
    var encontrado = false;

    $('#codigo option').each(function(){
        var $o = $(this);
        var cod = extraerCodigoDesdeTextoCatalogo($o.val()) ||
                  extraerCodigoDesdeTextoCatalogo($o.attr('data-codigo')) ||
                  extraerCodigoDesdeTextoCatalogo($o.text());

        if(cod === codigo){
            $o.prop('selected', true);
            encontrado = true;
            return false;
        }
    });

    if(!encontrado && codigo !== ''){
        $('#codigo').val(codigo);
    }
}

function marcarModoAutomaticoCatalogo(){
    $('#descripcion').data('manual', false);
    $('#descripcion_corta').data('manual', false);
    $('#porcentaje_igv').data('manual', false);
    $('#orden').data('manual', false);
}

function limpiarCatalogoAfectaciones(){
    $('#id').val('0');
    $('#formCatalogoAfectaciones').data('codigo-original', '');
    seleccionarCodigoCatalogo('10');
    $('#descripcion').val('');
    $('#descripcion_corta').val('');
    $('#cod_tributo').val('1000');
    $('#porcentaje_igv').val('18.00');
    $('#orden').val('10');
    $('#btnGuardarCatalogo').text('Guardar');
    marcarModoAutomaticoCatalogo();
    ajustarTributoPorCodigo();
}

function ajustarTributoPorCodigo(){
    var codigo = codigoCatalogoActual() || '10';

    var map = {
        '10': {cod:'1000', pct:'18.00', ord:'10'},
        '11': {cod:'9996', pct:'18.00', ord:'11'},
        '12': {cod:'9996', pct:'18.00', ord:'12'},
        '13': {cod:'9996', pct:'18.00', ord:'13'},
        '14': {cod:'9996', pct:'18.00', ord:'14'},
        '15': {cod:'9996', pct:'18.00', ord:'15'},
        '16': {cod:'9996', pct:'18.00', ord:'16'},
        '20': {cod:'9997', pct:'0.00',  ord:'20'},
        '21': {cod:'9997', pct:'0.00',  ord:'21'},
        '30': {cod:'9998', pct:'0.00',  ord:'30'},
        '31': {cod:'9998', pct:'0.00',  ord:'31'},
        '32': {cod:'9998', pct:'0.00',  ord:'32'},
        '33': {cod:'9998', pct:'0.00',  ord:'33'},
        '34': {cod:'9998', pct:'0.00',  ord:'34'},
        '35': {cod:'9998', pct:'0.00',  ord:'35'},
        '36': {cod:'9998', pct:'0.00',  ord:'36'}
    };

    var opt = $('#codigo option:selected');
    var descripcion = opt.data('descripcion') || opt.text();
    var descripcionCorta = opt.data('descripcion-corta') || descripcion;

    if(map[codigo]){
        $('#cod_tributo').val(map[codigo].cod);

        if(!$('#descripcion').data('manual')){ $('#descripcion').val(descripcion); }
        if(!$('#descripcion_corta').data('manual')){ $('#descripcion_corta').val(descripcionCorta); }
        if(!$('#porcentaje_igv').data('manual')){ $('#porcentaje_igv').val(map[codigo].pct); }
        if(!$('#orden').data('manual')){ $('#orden').val(map[codigo].ord); }

        if(['20','21','30','31','32','33','34','35','36'].indexOf(codigo) >= 0){
            $('#porcentaje_igv').prop('readonly', true).val('0.00');
        }else{
            $('#porcentaje_igv').prop('readonly', false);
        }
    }
}

function initCatalogoAfectaciones(){
    tablaCatalogoAfectaciones = $('#tbllistado_catalogo_afectaciones').DataTable({
        processing: true,
        serverSide: false,
        ajax: {
            url: 'data/catalogo-afectaciones.php?op=listar',
            type: 'get',
            dataType: 'json',
            error: function(e){ console.log(e.responseText); }
        },
        destroy: true,
        pageLength: 25,
        order: [[1, 'asc']],
        dom: 'Bfrtip',
        buttons: ['copyHtml5','excelHtml5','csvHtml5','pdf']
    });

    $('#formCatalogoAfectaciones').off('submit').on('submit', function(e){
        e.preventDefault();

        var formData = new FormData(this);
        var codigoReal = codigoCatalogoActual();
        if(codigoReal === ''){
            codigoReal = codigoCatalogoRespaldo();
        }
        if(codigoReal !== ''){
            formData.set('codigo', codigoReal);
        }

        $.ajax({
            url: 'data/catalogo-afectaciones.php?op=guardaryeditar',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(resp){
                Swal.fire(resp);
                var r = String(resp || '').toLowerCase();
                if(r.indexOf('actualizado') >= 0 || r.indexOf('guardado') >= 0){
                    limpiarCatalogoAfectaciones();
                    tablaCatalogoAfectaciones.ajax.reload(null, false);
                }
            }
        });
    });

    $('#codigo').off('change').on('change', function(){
        marcarModoAutomaticoCatalogo();
        ajustarTributoPorCodigo();
    });

    $('#descripcion').off('input').on('input', function(){ $(this).data('manual', true); });
    $('#descripcion_corta').off('input').on('input', function(){ $(this).data('manual', true); });
    $('#porcentaje_igv').off('input').on('input', function(){ $(this).data('manual', true); });
    $('#orden').off('input').on('input', function(){ $(this).data('manual', true); });

    ajustarTributoPorCodigo();
}

function mostrar(id){
    $.post('data/catalogo-afectaciones.php?op=mostrar', {id:id}, function(data){
        data = JSON.parse(data);

        $('#id').val(data.id);
        $('#formCatalogoAfectaciones').data('codigo-original', data.codigo || '');
        seleccionarCodigoCatalogo(data.codigo);
        $('#descripcion').val(data.descripcion).data('manual', true);
        $('#descripcion_corta').val(data.descripcion_corta || '').data('manual', true);
        $('#cod_tributo').val(data.cod_tributo);
        $('#porcentaje_igv').val(parseFloat(data.porcentaje_igv).toFixed(2)).data('manual', true);
        $('#orden').val(data.orden).data('manual', true);
        $('#btnGuardarCatalogo').text('Actualizar');

        ajustarTributoPorCodigo();

        $('html, body').animate({
            scrollTop: $('#panelCatalogoAfectaciones').offset().top - 20
        }, 200);
    });
}

function desactivar(id){
    Swal.fire({
        title:'Desactivar registro?',
        icon:'question',
        showCancelButton:true,
        confirmButtonText:'Sí'
    }).then(function(res){
        if(res.isConfirmed){
            $.post('data/catalogo-afectaciones.php?op=desactivar', {id:id}, function(resp){
                Swal.fire(resp);
                tablaCatalogoAfectaciones.ajax.reload(null,false);
            });
        }
    });
}

function activar(id){
    Swal.fire({
        title:'Activar registro?',
        icon:'question',
        showCancelButton:true,
        confirmButtonText:'Sí'
    }).then(function(res){
        if(res.isConfirmed){
            $.post('data/catalogo-afectaciones.php?op=activar', {id:id}, function(resp){
                Swal.fire(resp);
                tablaCatalogoAfectaciones.ajax.reload(null,false);
            });
        }
    });
}


function eliminar(id){
    Swal.fire({
        title:'Eliminar registro?',
        text:'Esta acción no se puede deshacer.',
        icon:'warning',
        showCancelButton:true,
        confirmButtonText:'Sí, eliminar'
    }).then(function(res){
        if(res.isConfirmed){
            $.post('data/catalogo-afectaciones.php?op=eliminar', {id:id}, function(resp){
                Swal.fire(resp);
                tablaCatalogoAfectaciones.ajax.reload(null,false);
                if(String($('#id').val()) === String(id)){
                    limpiarCatalogoAfectaciones();
                }
            });
        }
    });
}

$(document).ready(function(){
    initCatalogoAfectaciones();
    limpiarCatalogoAfectaciones();
});
