<?php

// ======================================================
// SUNAT: Redondeo a la UNIDAD (detracción depósito en PEN)
// ======================================================
if(!function_exists('sunat_round_unidad')){
function sunat_round_unidad($x){
    $x=(float)$x;
    if($x<=0){return 0;}
    $ent=floor($x);
    $frac=$x-$ent;
    return ($frac>=0.5)?($ent+1):$ent;
}}

if(!function_exists('fmt2')){
function fmt2($x){ return number_format((float)$x,2,'.',''); }
}


require_once('../funcionesGlobales/validaciones.php');


function cpeFactura($ruta, $cabecera, $detalle) {
    try {
        $doc = new DOMDocument();
        $doc->formatOutput = FALSE;
        $doc->preserveWhiteSpace = TRUE;
        //$doc->encoding = 'ISO-8859-1';
        $doc->encoding = 'utf-8';
        $xmlCPE = '<?xml version="1.0" encoding="utf-8"?>
<Invoice xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" xmlns:ccts="urn:un:unece:uncefact:documentation:2" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2" xmlns:qdt="urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2" xmlns:udt="urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2" xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2">
	<ext:UBLExtensions>
		<ext:UBLExtension>
			<ext:ExtensionContent>
			</ext:ExtensionContent>
		</ext:UBLExtension>
	</ext:UBLExtensions>
	<cbc:UBLVersionID>2.1</cbc:UBLVersionID>
	<cbc:CustomizationID schemeAgencyName="PE:SUNAT">2.0</cbc:CustomizationID>
	<cbc:ProfileID schemeName="Tipo de Operacion" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo51">' . $cabecera["TIPO_OPERACION"] . '</cbc:ProfileID>
	<cbc:ID>' . $cabecera["NRO_COMPROBANTE"] . '</cbc:ID>
	<cbc:IssueDate>' . $cabecera["FECHA_DOCUMENTO"] . '</cbc:IssueDate>
	<cbc:IssueTime>00:00:00</cbc:IssueTime>
	<cbc:DueDate>' . $cabecera["FECHA_VTO"] . '</cbc:DueDate>
	<cbc:InvoiceTypeCode listID="' . $cabecera["TIPO_OPERACION"] . '" >' . $cabecera["COD_TIPO_DOCUMENTO"] . '</cbc:InvoiceTypeCode>';
	
if ($cabecera["TOTAL_LETRAS"] <> "") {
$xmlCPE=$xmlCPE.'<cbc:Note languageLocaleID="1000">' . $cabecera["TOTAL_LETRAS"] . '</cbc:Note>';
}
if ($cabecera["TOTAL_DETRACCIONES"] > 0) {
 $xmlCPE = $xmlCPE .'<cbc:Note languageLocaleID="2006">Operacion sujeta a detraccion</cbc:Note>';
}
        
$xmlCPE = $xmlCPE .
                '<cbc:DocumentCurrencyCode listID="ISO 4217 Alpha" listName="Currency" listAgencyName="United Nations Economic Commission for Europe">' . $cabecera["COD_MONEDA"] . '</cbc:DocumentCurrencyCode>
            <cbc:LineCountNumeric>' . count($detalle) . '</cbc:LineCountNumeric>';
		
        if ($cabecera["NRO_OTR_COMPROBANTE"] <> "") {
            $xmlCPE = $xmlCPE .
                    '<cac:OrderReference>
                    <cbc:ID>' . $cabecera["NRO_OTR_COMPROBANTE"] . '</cbc:ID>
            </cac:OrderReference>';
        }
        if ($cabecera["NRO_GUIA_REMISION"] <> "") {
       
$xmlCPE = $xmlCPE .'	
<cac:DespatchDocumentReference>
<cbc:ID>' . $cabecera["NRO_GUIA_REMISION"] . '</cbc:ID>
<cbc:DocumentTypeCode>' . $cabecera["COD_GUIA_REMISION"] . '</cbc:DocumentTypeCode>
</cac:DespatchDocumentReference>';

		}
		
//AQUI AGREGAMOS EL DOCUMENTO DE REFERENCIA DE ANTICIPO		
if ($cabecera["NROACTICIPO"] <> "") {	
 for ($z = 0; $z < count($cabecera["NROACTICIPO"]); $z++) {
	
            $xmlCPE = $xmlCPE .
'<cac:AdditionalDocumentReference>
<cbc:ID>'.$cabecera["NROACTICIPO"][$z]["serienumero"]. '</cbc:ID>
      <cbc:DocumentTypeCode>02</cbc:DocumentTypeCode>
      <cbc:DocumentStatusCode>'.$cabecera["NROACTICIPO"][$z]["orden"].'</cbc:DocumentStatusCode>
      <cac:IssuerParty>
         <cac:PartyIdentification><cbc:ID schemeID="6">'.$cabecera["NRO_DOCUMENTO_EMPRESA"].'</cbc:ID>
         </cac:PartyIdentification>
      </cac:IssuerParty>
   </cac:AdditionalDocumentReference>';

}
}
		
$xmlCPE = $xmlCPE .
                '<cac:Signature>
		<cbc:ID>' . $cabecera["NRO_COMPROBANTE"] . '</cbc:ID>
		<cac:SignatoryParty>
			<cac:PartyIdentification>
				<cbc:ID>' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
			</cac:PartyIdentification>
			<cac:PartyName>
				<cbc:Name><![CDATA[' . $cabecera["RAZON_SOCIAL_EMPRESA"] . ']]></cbc:Name>
			</cac:PartyName>
		</cac:SignatoryParty>
		<cac:DigitalSignatureAttachment>
			<cac:ExternalReference>
				<cbc:URI>#' . $cabecera["NRO_COMPROBANTE"] . '</cbc:URI>
			</cac:ExternalReference>
		</cac:DigitalSignatureAttachment>
	</cac:Signature>
	<cac:AccountingSupplierParty>
		<cac:Party>
			<cac:PartyIdentification>
				<cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_EMPRESA"] . '" schemeName="Documento de Identidad" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06">' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
			</cac:PartyIdentification>
			<cac:PartyName>
				<cbc:Name>' . $cabecera["NOMBRE_COMERCIAL_EMPRESA"] . '</cbc:Name>
			</cac:PartyName>
			<cac:PartyTaxScheme>
				<cbc:RegistrationName><![CDATA[' . $cabecera["RAZON_SOCIAL_EMPRESA"] . ']]></cbc:RegistrationName>
				<cbc:CompanyID schemeID="' . $cabecera["TIPO_DOCUMENTO_EMPRESA"] . '" >' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:CompanyID>
				<cac:TaxScheme>
					<cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_EMPRESA"] . '" >' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
				</cac:TaxScheme>
			</cac:PartyTaxScheme>
			<cac:PartyLegalEntity>
				<cbc:RegistrationName><![CDATA[' . $cabecera["RAZON_SOCIAL_EMPRESA"] . ']]></cbc:RegistrationName>			
<cac:RegistrationAddress>
	<cbc:ID>' . $cabecera["CODIGO_UBIGEO_EMPRESA"] . '</cbc:ID>
<cbc:AddressTypeCode>' . $cabecera["IDSUNAT"] . '</cbc:AddressTypeCode>
<cbc:CityName><![CDATA[' . $cabecera["DEPARTAMENTO_EMPRESA"] . ']]></cbc:CityName>
<cbc:CountrySubentity><![CDATA[' . $cabecera["PROVINCIA_EMPRESA"] . ']]></cbc:CountrySubentity>
<cbc:District><![CDATA[' . $cabecera["DISTRITO_EMPRESA"] . ']]></cbc:District>
<cac:AddressLine>
<cbc:Line><![CDATA[' . $cabecera["DIRECCION_EMPRESA"] . ']]></cbc:Line>
</cac:AddressLine>
<cac:Country>
<cbc:IdentificationCode>' . $cabecera["CODIGO_PAIS_EMPRESA"] . '</cbc:IdentificationCode>
</cac:Country>
</cac:RegistrationAddress>
</cac:PartyLegalEntity>
			<cac:Contact>
				<cbc:Name><![CDATA[' . $cabecera["CONTACTO_EMPRESA"] . ']]></cbc:Name>
			</cac:Contact>
		</cac:Party>
	</cac:AccountingSupplierParty>
	<cac:AccountingCustomerParty>
		<cac:Party>
			<cac:PartyIdentification>
				<cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_CLIENTE"] . '" schemeName="Documento de Identidad" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06">' . $cabecera["NRO_DOCUMENTO_CLIENTE"] . '</cbc:ID>
			</cac:PartyIdentification>
			<cac:PartyName>
				<cbc:Name><![CDATA[' . $cabecera["RAZON_SOCIAL_CLIENTE"] . ']]></cbc:Name>
			</cac:PartyName>
			<cac:PartyTaxScheme>
				<cbc:RegistrationName><![CDATA[' . $cabecera["RAZON_SOCIAL_CLIENTE"] . ']]></cbc:RegistrationName>
				<cbc:CompanyID schemeID="' . $cabecera["TIPO_DOCUMENTO_CLIENTE"] . '" >' . $cabecera["NRO_DOCUMENTO_CLIENTE"] . '</cbc:CompanyID>
				<cac:TaxScheme>
					<cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_CLIENTE"] . '" >' . $cabecera["NRO_DOCUMENTO_CLIENTE"] . '</cbc:ID>
				</cac:TaxScheme>
			</cac:PartyTaxScheme>
			<cac:PartyLegalEntity>
				<cbc:RegistrationName><![CDATA[' . $cabecera["RAZON_SOCIAL_CLIENTE"] . ']]></cbc:RegistrationName>				
<cac:RegistrationAddress>
<cac:AddressLine>
<cbc:Line><![CDATA['.$cabecera["DIRECCION_CLIENTE"].']]></cbc:Line>
</cac:AddressLine>
<cac:Country>
<cbc:IdentificationCode>'.$cabecera["COD_PAIS_CLIENTE"].'</cbc:IdentificationCode>
</cac:Country>
</cac:RegistrationAddress>'; 
                  
if(isset($cabecera["accionistas"])){
            for ($z = 0; $z < count($cabecera["accionistas"]); $z++) {
               $xmlCPE = $xmlCPE .
                '<cac:ShareholderParty>
                    <cac:Party>
                       <cac:PartyIdentification>
                          <cbc:ID schemeID="'.$cabecera["accionistas"][$z]["txtTIPO_DOCUMENTO_IDENTIDAD"].'" schemeName="Documento de Identidad" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06">'.$cabecera["accionistas"][$z]["txtNRO_DOCUMENTO_IDENTIDAD"].'</cbc:ID>
                       </cac:PartyIdentification>
                       <cac:PartyLegalEntity>
                           <cbc:RegistrationName>'.$cabecera["accionistas"][$z]["txtNOMBRE_ACCIONISTA"].'</cbc:RegistrationName>
                       </cac:PartyLegalEntity>
                     </cac:Party>
                 </cac:ShareholderParty>';
            }
	}	

				
 $xmlCPE = $xmlCPE .
                '</cac:PartyLegalEntity>
		</cac:Party>
	</cac:AccountingCustomerParty>';
		
        if ($cabecera["TOTAL_DETRACCIONES"] > 0) {
            $xmlCPE = $xmlCPE .
                    '
<cac:PaymentMeans>	
<cbc:ID>Detraccion</cbc:ID>
<cbc:PaymentMeansCode>' . $cabecera["COD_MEDIO_PAGO"] . '</cbc:PaymentMeansCode>
<cac:PayeeFinancialAccount>
<cbc:ID>' . $cabecera["CTA_BANCARIA_BN"] . '</cbc:ID>
</cac:PayeeFinancialAccount>
</cac:PaymentMeans>
<cac:PaymentTerms>
<cbc:ID>Detraccion</cbc:ID>
<cbc:PaymentMeansID>' . $cabecera["CODIGO_DETRACCION"] . '</cbc:PaymentMeansID>
<cbc:PaymentPercent>' . $cabecera["POR_DETRACCION"] . '</cbc:PaymentPercent>
<cbc:Amount currencyID="PEN">' . fmt2(sunat_round_unidad(str_replace(',','', (string)$cabecera["TOTAL_DETRACCIONES"]))) . '</cbc:Amount>
</cac:PaymentTerms>';
        }
		
		
		
//PERCEPCIONES
        if ($cabecera["TOTAL_PERCEPCIONES"] > 0) {
                       $xmlCPE = $xmlCPE .
'<cac:PaymentTerms>
<cbc:ID>Percepcion</cbc:ID>
<cbc:Amount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["PERCEMASTOTAL"] . '</cbc:Amount>
</cac:PaymentTerms>';
        }
		
//forma de pago	
		
            if ($cabecera["detalle_forma_pago"]=='') {
                $xmlCPE = $xmlCPE .
                    '<cac:PaymentTerms>        
                    <cbc:ID>FormaPago</cbc:ID>
            <cbc:PaymentMeansID schemeAgencyName="PE:SUNAT">Contado</cbc:PaymentMeansID>
                </cac:PaymentTerms>';
            }else{
				
$xmlCPE = $xmlCPE .
                    '<cac:PaymentTerms>
<cbc:ID>FormaPago</cbc:ID>
<cbc:PaymentMeansID>Credito</cbc:PaymentMeansID>
<cbc:Amount currencyID="'. $cabecera["COD_MONEDA"] .'">'.$cabecera["totalcredito"].'</cbc:Amount>
</cac:PaymentTerms>';
				
                for ($z = 0; $z < count($cabecera["detalle_forma_pago"]); $z++) {
                    $xmlCPE = $xmlCPE . "<cac:PaymentTerms>        
                    <cbc:ID>FormaPago</cbc:ID>
                    <cbc:PaymentMeansID schemeAgencyName='PE:SUNAT'>Cuota00" . $cabecera["detalle_forma_pago"][$z]["COD_FORMA_PAGO"] . "</cbc:PaymentMeansID>";
                            
                    if ($cabecera["detalle_forma_pago"][$z]["MONTO_FORMA_PAGO"]  > 0) {
                        $xmlCPE = $xmlCPE .  "<cbc:Amount currencyID='" . $cabecera["COD_MONEDA"] . "'>" . $cabecera["detalle_forma_pago"][$z]["MONTO_FORMA_PAGO"] . "</cbc:Amount>";
                    }
                    if ($cabecera["detalle_forma_pago"][$z]["FECHA_FORMA_PAGO"]!= "") {
                       $xmlCPE = $xmlCPE .  "<cbc:PaymentDueDate>"  . $cabecera["detalle_forma_pago"][$z]["FECHA_FORMA_PAGO"] .  "</cbc:PaymentDueDate>";
                    }
                    $xmlCPE = $xmlCPE .  " </cac:PaymentTerms>";
                }
           }

 
if ($cabecera["NROACTICIPO"] <> "") {	
 for ($z = 0; $z < count($cabecera["NROACTICIPO"]); $z++) {
	
$xmlCPE =$xmlCPE.
'<cac:PrepaidPayment>
      <cbc:ID>'.$cabecera["NROACTICIPO"][$z]["orden"].'</cbc:ID>
      <cbc:PaidAmount currencyID="PEN">'.$cabecera["NROACTICIPO"][$z]["monto"].'</cbc:PaidAmount>
   </cac:PrepaidPayment>';
}
	
	
 for ($z = 0; $z < count($cabecera["NROACTICIPO"]); $z++) {	
$xmlCPE =$xmlCPE.
'<cac:AllowanceCharge>
<cbc:ChargeIndicator>false</cbc:ChargeIndicator>
<cbc:AllowanceChargeReasonCode>04</cbc:AllowanceChargeReasonCode>
<cbc:MultiplierFactorNumeric>'.$cabecera["NROACTICIPO"][$z]["orden"].'</cbc:MultiplierFactorNumeric>
<cbc:Amount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$cabecera["NROACTICIPO"][$z]["monto"].'</cbc:Amount>
<cbc:BaseAmount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$cabecera["NROACTICIPO"][$z]["monto"].'</cbc:BaseAmount>
</cac:AllowanceCharge>
';
}	
}	
if ($cabecera["TOTAL_PERCEPCIONES"] > 0) {
                $xmlCPE = $xmlCPE .  "<cac:AllowanceCharge>
<cbc:ChargeIndicator>true</cbc:ChargeIndicator>
<cbc:AllowanceChargeReasonCode>51</cbc:AllowanceChargeReasonCode>
<cbc:MultiplierFactorNumeric>" . $cabecera["PERCEPORCENTAJE"] . "</cbc:MultiplierFactorNumeric>
<cbc:Amount currencyID='" . $cabecera["COD_MONEDA"]  . "'>" . $cabecera["TOTAL_PERCEPCIONES"] . "</cbc:Amount>
<cbc:BaseAmount currencyID='".$cabecera["COD_MONEDA"]."'>".$cabecera["TOTAL"]."</cbc:BaseAmount>
</cac:AllowanceCharge>";
        }
		
        if ($cabecera["TOTAL_RETENCIONES"] > 0) {
                $xmlCPE = $xmlCPE .  "<cac:AllowanceCharge>
                              <cbc:ChargeIndicator>false</cbc:ChargeIndicator>
                              <cbc:AllowanceChargeReasonCode listAgencyName='PE:SUNAT' listName='Cargo/descuento' listURI='urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo53'>62</cbc:AllowanceChargeReasonCode>
                              <cbc:AllowanceChargeReason><![CDATA[Retencion]]></cbc:AllowanceChargeReason>
                              <cbc:MultiplierFactorNumeric>" . $cabecera["POR_RETENCIONES"] . "</cbc:MultiplierFactorNumeric>
                              <cbc:Amount currencyID='" . $cabecera["COD_MONEDA"]  . "'>" . $cabecera["TOTAL_RETENCIONES"] . "</cbc:Amount>
                              <cbc:BaseAmount currencyID='" . $cabecera["COD_MONEDA"]  . "'>" . $cabecera["BI_RETENCIONES"] . "</cbc:BaseAmount>
                           </cac:AllowanceCharge>";
        }
/*	
if ($cabecera["TOTAL_DESCUENTO"] > 0) {
               $xmlCPE = $xmlCPE .
                       '<cac:AllowanceCharge>
                       <cbc:ChargeIndicator>false</cbc:ChargeIndicator>
                       <cbc:AllowanceChargeReasonCode listName="Cargo/descuento" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo53">00</cbc:AllowanceChargeReasonCode>
<cbc:Amount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_DESCUENTO"] . '</cbc:Amount>
                       </cac:AllowanceCharge>';
        }
      */
      
 $xmlCPE = $xmlCPE .'<cac:TaxTotal><cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_IGV"] . '</cbc:TaxAmount>'; 

if ($cabecera["TOTAL_EXPORTACION"]=='0.00') {
	$xmlCPE = $xmlCPE .
                '<cac:TaxSubtotal>
<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_GRAVADAS"] . '</cbc:TaxableAmount>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_IGV"] . '</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">S</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">1000</cbc:ID>
					<cbc:Name>IGV</cbc:Name>
					<cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
	
}
	
        if ($cabecera["TOTAL_ISC"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_ISC"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_ISC"] . '</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">S</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">2000</cbc:ID>
					<cbc:Name>ISC</cbc:Name>
					<cbc:TaxTypeCode>EXC</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        //CAMPO NUEVO
        if ($cabecera["TOTAL_EXPORTACION"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_EXPORTACION"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0.00</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">G</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9995</cbc:ID>
					<cbc:Name>EXP</cbc:Name>
					<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_GRATUITAS"] > 0) {
            $igvGratuitas = isset($cabecera["TOTAL_IGV_GRATUITAS"]) ? $cabecera["TOTAL_IGV_GRATUITAS"] : '0.00';
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_GRATUITAS"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $igvGratuitas . '</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">Z</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9996</cbc:ID>
					<cbc:Name>GRA</cbc:Name>
					<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_EXONERADAS"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_EXONERADAS"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0.00</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">E</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9997</cbc:ID>
					<cbc:Name>EXO</cbc:Name>
					<cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_INAFECTA"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_INAFECTA"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0.00</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">O</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9998</cbc:ID>
					<cbc:Name>INA</cbc:Name>
					<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_OTR_IMP"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_OTR_IMP"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_OTR_IMP"] . '</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">S</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9999</cbc:ID>
					<cbc:Name>OTR</cbc:Name>
					<cbc:TaxTypeCode>OTH</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        //TOTAL=GRAVADA+IGV+EXONERADA
        //NO ENTRA GRATUITA(INAFECTA) NI DESCUENTO
        //SUB_TOTAL=PRECIO(SIN IGV) * CANTIDAD
 $xmlCPE = $xmlCPE .
                '</cac:TaxTotal>
	<cac:LegalMonetaryTotal>';

if ($cabecera["NROACTICIPO"] <> "") {
	
$xmlCPE =$xmlCPE.'
<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["subanticipo"] . '</cbc:LineExtensionAmount>
<cbc:TaxInclusiveAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["totalanticipo"] . '</cbc:TaxInclusiveAmount>
<cbc:PrepaidAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["pagadoanticipo"] . '</cbc:PrepaidAmount>
<cbc:PayableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$cabecera["TOTAL"].'</cbc:PayableAmount>
';
	
}else{
$xmlCPE =$xmlCPE.'
<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["SUB_TOTAL"] . '</cbc:LineExtensionAmount>
<cbc:TaxInclusiveAmount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$cabecera["TOTAL"].'</cbc:TaxInclusiveAmount>
<cbc:PayableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$cabecera["TOTAL"].'</cbc:PayableAmount>
';	
}
		
		
$xmlCPE=$xmlCPE.'</cac:LegalMonetaryTotal>';
		
		
        for ($i = 0; $i < count($detalle); $i++) {
            if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="10"){
            $xmlCPE = $xmlCPE . '<cac:InvoiceLine>
		<cbc:ID>' . $detalle[$i]["txtITEM"] . '</cbc:ID>
		<cbc:InvoicedQuantity unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '" unitCodeListID="UN/ECE rec 20" unitCodeListAgencyName="United Nations Economic Commission for Europe">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:InvoicedQuantity>
		<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:LineExtensionAmount>
		<cac:PricingReference>
			<cac:AlternativeConditionPrice>
				<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_DET"] . '</cbc:PriceAmount>
				<cbc:PriceTypeCode listName="Tipo de Precio" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo16">' . $detalle[$i]["txtPRECIO_TIPO_CODIGO"] . '</cbc:PriceTypeCode>
			</cac:AlternativeConditionPrice>
		</cac:PricingReference>';

				
if($detalle[$i]["descuento"]!=''){
 $xmlCPE = $xmlCPE . '
<cac:AllowanceCharge>
<cbc:ChargeIndicator>false</cbc:ChargeIndicator>
<cbc:AllowanceChargeReasonCode listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo53" listName="Cargo/descuento" listAgencyName="PE:SUNAT">00</cbc:AllowanceChargeReasonCode>
<cbc:MultiplierFactorNumeric>'.$detalle[$i]["porcentaje"].'</cbc:MultiplierFactorNumeric>
<cbc:Amount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$detalle[$i]["descuento"].'</cbc:Amount>
<cbc:BaseAmount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$detalle[$i]["totalfinal"].'</cbc:BaseAmount>
</cac:AllowanceCharge>
';		
}

 $xmlCPE = $xmlCPE . '<cac:TaxTotal>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
			<cac:TaxSubtotal>
				<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
				<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
				<cac:TaxCategory>
					<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">S</cbc:ID>
					<cbc:Percent>' . $cabecera["POR_IGV"] . '</cbc:Percent>
<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
					<cac:TaxScheme>
						<cbc:ID>1000</cbc:ID>
						<cbc:Name>IGV</cbc:Name>
						<cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
					</cac:TaxScheme>
				</cac:TaxCategory>
			</cac:TaxSubtotal>
		</cac:TaxTotal>
		<cac:Item>
			<cbc:Description><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtDESCRIPCION_DET"])) ? $detalle[$i]["txtDESCRIPCION_DET"] : "") . ']]></cbc:Description>
			<cac:SellersItemIdentification>
				<cbc:ID><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtCODIGO_DET"])) ? $detalle[$i]["txtCODIGO_DET"] : "") . ']]></cbc:ID>
			</cac:SellersItemIdentification>';

if(isset($detalle[$i]["propiedad_adicional"])){
            for ($y = 0; $y < count($detalle[$i]["propiedad_adicional"]); $y++) {
               $xmlCPE = $xmlCPE .
                '<cac:AdditionalItemProperty>
                           <cbc:Name>'.$detalle[$i]["propiedad_adicional"][$y]["txtNOMBRE"].'</cbc:Name>
                           <cbc:NameCode listName="Propiedad del item" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo55">'.$detalle[$i]["propiedad_adicional"][$y]["txtCODIGO"].'</cbc:NameCode>
                           <cbc:Value>'.$detalle[$i]["propiedad_adicional"][$y]["txtVALOR"].'</cbc:Value>
                       </cac:AdditionalItemProperty>';
            }
}				

  $xmlCPE = $xmlCPE .
                '</cac:Item>
		<cac:Price>
			<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_SIN_IGV_DET"] . '</cbc:PriceAmount>
		</cac:Price>
	</cac:InvoiceLine>';
            }
if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="20"||$detalle[$i]["txtCOD_TIPO_OPERACION"]=="40"){
    
            $xmlCPE = $xmlCPE . '<cac:InvoiceLine>
		<cbc:ID>' . $detalle[$i]["txtITEM"] . '</cbc:ID>
		<cbc:InvoicedQuantity unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '" unitCodeListID="UN/ECE rec 20" unitCodeListAgencyName="United Nations Economic Commission for Europe">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:InvoicedQuantity>
		<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:LineExtensionAmount>
		<cac:PricingReference>
			<cac:AlternativeConditionPrice>
				<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_DET"] . '</cbc:PriceAmount>
				<cbc:PriceTypeCode listName="Tipo de Precio" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo16">' . $detalle[$i]["txtPRECIO_TIPO_CODIGO"] . '</cbc:PriceTypeCode>
			</cac:AlternativeConditionPrice>
		</cac:PricingReference>';
		
if($detalle[$i]["descuento"]!=''){
$xmlCPE = $xmlCPE . '
<cac:AllowanceCharge>
<cbc:ChargeIndicator>false</cbc:ChargeIndicator>
<cbc:AllowanceChargeReasonCode listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo53" listName="Cargo/descuento" listAgencyName="PE:SUNAT">00</cbc:AllowanceChargeReasonCode>
<cbc:MultiplierFactorNumeric>'.$detalle[$i]["porcentaje"].'</cbc:MultiplierFactorNumeric>
<cbc:Amount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$detalle[$i]["descuento"].'</cbc:Amount>
<cbc:BaseAmount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$detalle[$i]["totalfinal"].'</cbc:BaseAmount>
</cac:AllowanceCharge>
';		
}
		
		
$xmlCPE = $xmlCPE . '<cac:TaxTotal>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
			<cac:TaxSubtotal>
				<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
				<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
				<cac:TaxCategory>
					<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">E</cbc:ID>
					<cbc:Percent>0</cbc:Percent>
					<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>';
					
if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="20"){
$xmlCPE = $xmlCPE . '<cac:TaxScheme>
					<cbc:ID>9997</cbc:ID>
						<cbc:Name>EXO</cbc:Name>
						<cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
					</cac:TaxScheme>';
}else{
$xmlCPE = $xmlCPE . '<cac:TaxScheme>
					<cbc:ID>9995</cbc:ID>
						<cbc:Name>EXP</cbc:Name>
						<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
					</cac:TaxScheme>'; 
}

$xmlCPE = $xmlCPE . '</cac:TaxCategory>
			</cac:TaxSubtotal>
		</cac:TaxTotal>
		<cac:Item>
			<cbc:Description><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtDESCRIPCION_DET"])) ? $detalle[$i]["txtDESCRIPCION_DET"] : "") . ']]></cbc:Description>
			<cac:SellersItemIdentification>
				<cbc:ID><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtCODIGO_DET"])) ? $detalle[$i]["txtCODIGO_DET"] : "") . ']]></cbc:ID>
			</cac:SellersItemIdentification>';

if (isset($detalle[$i]["propiedad_adicional"])) {				
				
            for ($y = 0; $y < count($detalle[$i]["propiedad_adicional"]); $y++) {
               $xmlCPE = $xmlCPE .
                '<cac:AdditionalItemProperty>
                           <cbc:Name>'.$detalle[$i]["propiedad_adicional"][$y]["txtNOMBRE"].'</cbc:Name>
                           <cbc:NameCode listName="Propiedad del item" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo55">'.$detalle[$i]["propiedad_adicional"][$y]["txtCODIGO"].'</cbc:NameCode>
                           <cbc:Value>'.$detalle[$i]["propiedad_adicional"][$y]["txtVALOR"].'</cbc:Value>
                       </cac:AdditionalItemProperty>';
            }
				
}				
				

  $xmlCPE = $xmlCPE .
                '</cac:Item>
		<cac:Price>
			<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_SIN_IGV_DET"] . '</cbc:PriceAmount>
		</cac:Price>
	</cac:InvoiceLine>';
            }
            if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="30"){
            $xmlCPE = $xmlCPE . '<cac:InvoiceLine>
		<cbc:ID>' . $detalle[$i]["txtITEM"] . '</cbc:ID>
		<cbc:InvoicedQuantity unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '" unitCodeListID="UN/ECE rec 20" unitCodeListAgencyName="United Nations Economic Commission for Europe">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:InvoicedQuantity>
		<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:LineExtensionAmount>
		<cac:PricingReference>
			<cac:AlternativeConditionPrice>
				<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_DET"] . '</cbc:PriceAmount>
				<cbc:PriceTypeCode listName="Tipo de Precio" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo16">' . $detalle[$i]["txtPRECIO_TIPO_CODIGO"] . '</cbc:PriceTypeCode>
			</cac:AlternativeConditionPrice>
		</cac:PricingReference>';
		
if($detalle[$i]["descuento"]!=''){
$xmlCPE = $xmlCPE . '
<cac:AllowanceCharge>
<cbc:ChargeIndicator>false</cbc:ChargeIndicator>
<cbc:AllowanceChargeReasonCode listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo53" listName="Cargo/descuento" listAgencyName="PE:SUNAT">00</cbc:AllowanceChargeReasonCode>
<cbc:MultiplierFactorNumeric>'.$detalle[$i]["porcentaje"].'</cbc:MultiplierFactorNumeric>
<cbc:Amount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$detalle[$i]["descuento"].'</cbc:Amount>
<cbc:BaseAmount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$detalle[$i]["totalfinal"].'</cbc:BaseAmount>
</cac:AllowanceCharge>
';		
}
		
$xmlCPE = $xmlCPE . '<cac:TaxTotal>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
			<cac:TaxSubtotal>
				<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
				<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
				<cac:TaxCategory>
					<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">O</cbc:ID>
					<cbc:Percent>0</cbc:Percent>
					<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
					<cac:TaxScheme>
						<cbc:ID>9998</cbc:ID>
						<cbc:Name>INA</cbc:Name>
						<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
					</cac:TaxScheme>
				</cac:TaxCategory>
			</cac:TaxSubtotal>
		</cac:TaxTotal>
		<cac:Item>
			<cbc:Description><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtDESCRIPCION_DET"])) ? $detalle[$i]["txtDESCRIPCION_DET"] : "") . ']]></cbc:Description>
			<cac:SellersItemIdentification>
				<cbc:ID><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtCODIGO_DET"])) ? $detalle[$i]["txtCODIGO_DET"] : "") . ']]></cbc:ID>
			</cac:SellersItemIdentification>';

if(isset($detalle[$i]["propiedad_adicional"])) {		
				
            for ($y = 0; $y < count($detalle[$i]["propiedad_adicional"]); $y++) {
               $xmlCPE = $xmlCPE .
                '<cac:AdditionalItemProperty>
                           <cbc:Name>'.$detalle[$i]["propiedad_adicional"][$y]["txtNOMBRE"].'</cbc:Name>
                           <cbc:NameCode listName="Propiedad del item" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo55">'.$detalle[$i]["propiedad_adicional"][$y]["txtCODIGO"].'</cbc:NameCode>
                           <cbc:Value>'.$detalle[$i]["propiedad_adicional"][$y]["txtVALOR"].'</cbc:Value>
                       </cac:AdditionalItemProperty>';
            }
				
			 }	

  $xmlCPE = $xmlCPE .
                '</cac:Item>
		<cac:Price>
			<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_SIN_IGV_DET"] . '</cbc:PriceAmount>
		</cac:Price>
	</cac:InvoiceLine>';
            }
            if ($detalle[$i]["txtCOD_TIPO_OPERACION"] == "31" || $detalle[$i]["txtCOD_TIPO_OPERACION"] == "14" || $detalle[$i]["txtCOD_TIPO_OPERACION"] == "15") {
                $es1415 = ($detalle[$i]["txtCOD_TIPO_OPERACION"] == "14" || $detalle[$i]["txtCOD_TIPO_OPERACION"] == "15");
                $priceTypeCode = '02';
                $taxableRef = (isset($detalle[$i]["valor_total_ref"]) && ($detalle[$i]["txtCOD_TIPO_OPERACION"] == "14" || $detalle[$i]["txtCOD_TIPO_OPERACION"] == "15")) ? $detalle[$i]["valor_total_ref"] : $detalle[$i]["txtIMPORTE_DET"];
                $taxAmountRef = $es1415 ? (isset($detalle[$i]["igv_ref"]) ? $detalle[$i]["igv_ref"] : $detalle[$i]["txtIGV"]) : '0';
                $taxSchemeId = '9996';
                $taxSchemeName = 'GRA';
                $taxType = 'FRE';
                $taxCatId = 'Z';
                $taxPercent = '0';
                $xmlCPE = $xmlCPE . '<cac:InvoiceLine>
		<cbc:ID>' . $detalle[$i]["txtITEM"] . '</cbc:ID>
		<cbc:InvoicedQuantity unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '" unitCodeListID="UN/ECE rec 20" unitCodeListAgencyName="United Nations Economic Commission for Europe">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:InvoicedQuantity>
		<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:LineExtensionAmount>
		<cac:PricingReference>
			<cac:AlternativeConditionPrice>
				<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_DET"] . '</cbc:PriceAmount>
				<cbc:PriceTypeCode listName="Tipo de Precio" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo16">'.$priceTypeCode.'</cbc:PriceTypeCode>
			</cac:AlternativeConditionPrice>
		</cac:PricingReference>
		<cac:TaxTotal>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$taxAmountRef.'</cbc:TaxAmount>';

                if ($detalle[$i]["FLG_ICBPER"] > 0) {
                    $xmlCPE = $xmlCPE . '<cac:TaxSubtotal>                                   
                                    <cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["IMPORTE_BP"] . '</cbc:TaxAmount>
                                    <cbc:BaseUnitMeasure unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:BaseUnitMeasure>
                                    <cac:TaxCategory>                                       
                                        <cbc:PerUnitAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["IMPUESTO_BP"] . '</cbc:PerUnitAmount>                                                                                
                                        <cac:TaxScheme>
                                            <cbc:ID schemeAgencyName="PE:SUNAT" schemeName="Codigo de tributos" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo05">7152</cbc:ID>
                                            <cbc:Name>ICBPER</cbc:Name>
                                            <cbc:TaxTypeCode>OTH</cbc:TaxTypeCode>
                                        </cac:TaxScheme>
                                    </cac:TaxCategory>
                                </cac:TaxSubtotal>';
                }

                $xmlCPE = $xmlCPE . '<cac:TaxSubtotal>
				<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $taxableRef . '</cbc:TaxableAmount>
				<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">'.$taxAmountRef.'</cbc:TaxAmount>
				<cac:TaxCategory>
					<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">'.$taxCatId.'</cbc:ID>
					<cbc:Percent>'.$taxPercent.'</cbc:Percent>
					<cbc:TaxExemptionReasonCode listAgencyName="PE:SUNAT" listName="Afectacion del IGV" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo07">' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
					<cac:TaxScheme>						
						<cbc:ID schemeAgencyName="PE:SUNAT" schemeID="UN/ECE 5153" schemeName="Codigo de tributos">'.$taxSchemeId.'</cbc:ID>
						<cbc:Name>'.$taxSchemeName.'</cbc:Name>
						<cbc:TaxTypeCode>'.$taxType.'</cbc:TaxTypeCode>
					</cac:TaxScheme>
				</cac:TaxCategory>
			</cac:TaxSubtotal>
		</cac:TaxTotal>
		<cac:Item>
<cbc:Description><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtDESCRIPCION_DET"])) ? $detalle[$i]["txtDESCRIPCION_DET"] : "") . ']]></cbc:Description>
			<cac:SellersItemIdentification>
				<cbc:ID><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtCODIGO_DET"])) ? $detalle[$i]["txtCODIGO_DET"] : "") . ']]></cbc:ID>
			</cac:SellersItemIdentification>';
                
                If ($detalle[$i]["txtCOD_SUNAT"]!=null) {
                        $xmlCPE = $xmlCPE .
                            "<cac:CommodityClassification>
			                    <cbc:ItemClassificationCode listID='UNSPSC' listAgencyName='GS1 US'
			                    listName='Item Classification'>" . $detalle[$i]["txtCOD_SUNAT"] . "</cbc:ItemClassificationCode>
			    </cac:CommodityClassification>";
                }

                if($detalle[$i]["propiedad_adicional"]!=null){
                for ($y = 0; $y < count($detalle[$i]["propiedad_adicional"]); $y++) {
                    $xmlCPE = $xmlCPE .
                            '<cac:AdditionalItemProperty>
                           <cbc:Name>' . $detalle[$i]["propiedad_adicional"][$y]["txtNOMBRE"] . '</cbc:Name>
                           <cbc:NameCode listName="Propiedad del item" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo55">' . $detalle[$i]["propiedad_adicional"][$y]["txtCODIGO"] . '</cbc:NameCode>
                           <cbc:Value>' . $detalle[$i]["propiedad_adicional"][$y]["txtVALOR"] . '</cbc:Value>
                       </cac:AdditionalItemProperty>';
                }
                }

                $xmlCPE = $xmlCPE .
                        '</cac:Item>
		<cac:Price>
			<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:PriceAmount>
		</cac:Price>
	</cac:InvoiceLine>';
            }
        }
        $xmlCPE = $xmlCPE . '</Invoice>';

        $doc->loadXML($xmlCPE);
        $doc->save(dirname(__FILE__) . '/' . $ruta . '.XML');
    } catch (Exception $e) {
        //$nombre_archivo = "logs.txt";
        //echo 'Excepci髇 capturada: ', $e->getMessage(), "\n";
        $mensaje = $e->getMessage();
        $file = fopen("logs.txt", "w");
        fwrite($file, $mensaje . PHP_EOL);
        fwrite($file, "Otra m醩" . PHP_EOL);
        fclose($file);
    }
    return '1';
}

function cpeNC($ruta, $cabecera, $detalle) {
    $doc = new DOMDocument();
    $doc->formatOutput = FALSE;
    $doc->preserveWhiteSpace = TRUE;
    $doc->encoding = 'utf-8';
    //$doc->encoding = 'ISO-8859-1';
    //$doc->encoding = 'utf-8';
    $xmlCPE = '<?xml version="1.0" encoding="UTF-8"?>
<CreditNote xmlns="urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2" xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" xmlns:ccts="urn:un:unece:uncefact:documentation:2" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2" xmlns:qdt="urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2" xmlns:sac="urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1" xmlns:udt="urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <ext:UBLExtensions>
        <ext:UBLExtension>
            <ext:ExtensionContent>
            </ext:ExtensionContent>
        </ext:UBLExtension>
    </ext:UBLExtensions>
    <cbc:UBLVersionID>2.1</cbc:UBLVersionID>
    <cbc:CustomizationID>2.0</cbc:CustomizationID>
    <cbc:ID>' . $cabecera["NRO_COMPROBANTE"] . '</cbc:ID>
    <cbc:IssueDate>' . $cabecera["FECHA_DOCUMENTO"] . '</cbc:IssueDate>
    <cbc:IssueTime>00:00:00</cbc:IssueTime>
    <cbc:DocumentCurrencyCode>' . $cabecera["COD_MONEDA"] . '</cbc:DocumentCurrencyCode>
    <cac:DiscrepancyResponse>
        <cbc:ReferenceID>' . $cabecera["NRO_DOCUMENTO_MODIFICA"] . '</cbc:ReferenceID>
        <cbc:ResponseCode>' . $cabecera["COD_TIPO_MOTIVO"] . '</cbc:ResponseCode>
        <cbc:Description><![CDATA[' . $cabecera["DESCRIPCION_MOTIVO"] . ']]></cbc:Description>
    </cac:DiscrepancyResponse>
    <cac:BillingReference>
        <cac:InvoiceDocumentReference>
            <cbc:ID>' . $cabecera["NRO_DOCUMENTO_MODIFICA"] . '</cbc:ID>
            <cbc:DocumentTypeCode>' . $cabecera["TIPO_COMPROBANTE_MODIFICA"] . '</cbc:DocumentTypeCode>
        </cac:InvoiceDocumentReference>
    </cac:BillingReference>
    <cac:Signature>
        <cbc:ID>IDSignST</cbc:ID>
        <cac:SignatoryParty>
            <cac:PartyIdentification>
                <cbc:ID>' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
            </cac:PartyIdentification>
            <cac:PartyName>
                <cbc:Name><![CDATA[' . $cabecera["RAZON_SOCIAL_EMPRESA"] . ']]></cbc:Name>
            </cac:PartyName>
        </cac:SignatoryParty>
        <cac:DigitalSignatureAttachment>
            <cac:ExternalReference>
                <cbc:URI>#SignatureSP</cbc:URI>
            </cac:ExternalReference>
        </cac:DigitalSignatureAttachment>
    </cac:Signature>
    <cac:AccountingSupplierParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_EMPRESA"] . '" >' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
            </cac:PartyIdentification>
            <cac:PartyName>
                <cbc:Name><![CDATA[' . $cabecera["NOMBRE_COMERCIAL_EMPRESA"] . ']]></cbc:Name>
            </cac:PartyName>
            <cac:PartyLegalEntity>
<cbc:RegistrationName><![CDATA[' . $cabecera["RAZON_SOCIAL_EMPRESA"] . ']]></cbc:RegistrationName>
                <cac:RegistrationAddress>
                    <cbc:AddressTypeCode>' . $cabecera["IDSUNAT"] . '</cbc:AddressTypeCode>
                </cac:RegistrationAddress>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingSupplierParty>
    <cac:AccountingCustomerParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_CLIENTE"] . '" >' . $cabecera["NRO_DOCUMENTO_CLIENTE"] . '</cbc:ID>
            </cac:PartyIdentification>
            <cac:PartyLegalEntity>
<cbc:RegistrationName><![CDATA[' . $cabecera["RAZON_SOCIAL_CLIENTE"] . ']]></cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingCustomerParty>';
	
//forma de pago

if($cabecera["COD_TIPO_MOTIVO"]=='13') {
	
if ($cabecera["detalle_forma_pago"]=='') {
                $xmlCPE = $xmlCPE .
                    '<cac:PaymentTerms>        
                    <cbc:ID>FormaPago</cbc:ID>
            <cbc:PaymentMeansID schemeAgencyName="PE:SUNAT">Contado</cbc:PaymentMeansID>
                </cac:PaymentTerms>';
            }else{
				
	
$cuotas='0';
for ($z = 0; $z < count($cabecera["detalle_forma_pago"]); $z++) {	
$cuotas=$cuotas+$cabecera["detalle_forma_pago"][$z]["MONTO_FORMA_PAGO"];
}
$cuotas=round($cuotas, 2);	
	
$xmlCPE = $xmlCPE .
                    '<cac:PaymentTerms>
<cbc:ID>FormaPago</cbc:ID>
<cbc:PaymentMeansID>Credito</cbc:PaymentMeansID>
<cbc:Amount currencyID="'. $cabecera["COD_MONEDA"] .'">'.$cuotas.'</cbc:Amount>
</cac:PaymentTerms>';
				
                for ($z = 0; $z < count($cabecera["detalle_forma_pago"]); $z++) {
                    $xmlCPE = $xmlCPE . "<cac:PaymentTerms>        
                    <cbc:ID>FormaPago</cbc:ID>
                    <cbc:PaymentMeansID schemeAgencyName='PE:SUNAT'>Cuota00" . $cabecera["detalle_forma_pago"][$z]["COD_FORMA_PAGO"] . "</cbc:PaymentMeansID>";
                            
                    if ($cabecera["detalle_forma_pago"][$z]["MONTO_FORMA_PAGO"]  > 0) {
$xmlCPE = $xmlCPE .  "<cbc:Amount currencyID='".$cabecera["COD_MONEDA"]."'>".$cabecera["detalle_forma_pago"][$z]["MONTO_FORMA_PAGO"] . "</cbc:Amount>";
                    }
                    if ($cabecera["detalle_forma_pago"][$z]["FECHA_FORMA_PAGO"]!= "") {
                       $xmlCPE = $xmlCPE .  "<cbc:PaymentDueDate>"  . $cabecera["detalle_forma_pago"][$z]["FECHA_FORMA_PAGO"] .  "</cbc:PaymentDueDate>";
                    }
                    $xmlCPE = $xmlCPE .  " </cac:PaymentTerms>";
                }
           }

           }

	
	
        if ($cabecera["TOTAL_DESCUENTO"] > 0) {
               $xmlCPE = $xmlCPE .
                       '<cac:AllowanceCharge>
                       <cbc:ChargeIndicator>false</cbc:ChargeIndicator>
                       <cbc:AllowanceChargeReasonCode listName="Cargo/descuento" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo53">00</cbc:AllowanceChargeReasonCode>
                       <cbc:Amount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_DESCUENTO"] . '</cbc:Amount>
                       </cac:AllowanceCharge>';
        }
        
	$xmlCPE = $xmlCPE .
                '<cac:TaxTotal>
        <cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_IGV"] . '</cbc:TaxAmount>
        <cac:TaxSubtotal>
<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_GRAVADAS"] . '</cbc:TaxableAmount>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_IGV"] . '</cbc:TaxAmount>
            <cac:TaxCategory>
                <cac:TaxScheme>
                    <cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">1000</cbc:ID>
                    <cbc:Name>IGV</cbc:Name>
                    <cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
                </cac:TaxScheme>
            </cac:TaxCategory>
        </cac:TaxSubtotal>';
        
        if ($cabecera["TOTAL_ISC"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_ISC"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_ISC"] . '</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">S</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">2000</cbc:ID>
					<cbc:Name>ISC</cbc:Name>
					<cbc:TaxTypeCode>EXC</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        //CAMPO NUEVO
        if ($cabecera["TOTAL_EXPORTACION"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_EXPORTACION"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0.00</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">G</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9995</cbc:ID>
					<cbc:Name>EXP</cbc:Name>
					<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_GRATUITAS"] > 0) {
            $igvGratuitas = isset($cabecera["TOTAL_IGV_GRATUITAS"]) ? $cabecera["TOTAL_IGV_GRATUITAS"] : '0.00';
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_GRATUITAS"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $igvGratuitas . '</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">Z</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9996</cbc:ID>
					<cbc:Name>GRA</cbc:Name>
					<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_EXONERADAS"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_EXONERADAS"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0.00</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">E</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9997</cbc:ID>
					<cbc:Name>EXO</cbc:Name>
					<cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_INAFECTA"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_INAFECTA"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0.00</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">O</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9998</cbc:ID>
					<cbc:Name>INA</cbc:Name>
					<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_OTR_IMP"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_OTR_IMP"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_OTR_IMP"] . '</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">S</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9999</cbc:ID>
					<cbc:Name>OTR</cbc:Name>
					<cbc:TaxTypeCode>OTH</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        //TOTAL=GRAVADA+IGV+EXONERADA
        //NO ENTRA GRATUITA(INAFECTA) NI DESCUENTO
        //SUB_TOTAL=PRECIO(SIN IGV) * CANTIDAD
        $xmlCPE = $xmlCPE .
                '</cac:TaxTotal>
    <cac:LegalMonetaryTotal>
        <cbc:PayableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL"] . '</cbc:PayableAmount>
    </cac:LegalMonetaryTotal>';



    for ($i = 0; $i < count($detalle); $i++) {
        
		if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="10"){
            $xmlCPE = $xmlCPE . '<cac:CreditNoteLine>
        <cbc:ID>' . $detalle[$i]["txtITEM"] . '</cbc:ID>
<cbc:CreditedQuantity unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '">' .$detalle[$i]["txtCANTIDAD_DET"]. '</cbc:CreditedQuantity>
<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:LineExtensionAmount>
        <cac:PricingReference>
            <cac:AlternativeConditionPrice>
<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_DET"] . '</cbc:PriceAmount>
                <cbc:PriceTypeCode>' . $detalle[$i]["txtPRECIO_TIPO_CODIGO"] . '</cbc:PriceTypeCode>
            </cac:AlternativeConditionPrice>
        </cac:PricingReference>
        <cac:TaxTotal>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
            <cac:TaxSubtotal>
<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
                <cac:TaxCategory>
                    <cbc:Percent>' . $cabecera["POR_IGV"] . '</cbc:Percent>
<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
                    <cac:TaxScheme>
                        <cbc:ID>1000</cbc:ID>
                        <cbc:Name>IGV</cbc:Name>
                        <cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
                    </cac:TaxScheme>
                </cac:TaxCategory>
            </cac:TaxSubtotal>
        </cac:TaxTotal>
        <cac:Item>
<cbc:Description><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtDESCRIPCION_DET"])) ? $detalle[$i]["txtDESCRIPCION_DET"] : "") . ']]></cbc:Description>
            <cac:SellersItemIdentification>
                <cbc:ID><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtCODIGO_DET"])) ? $detalle[$i]["txtCODIGO_DET"] : "") . ']]></cbc:ID>
            </cac:SellersItemIdentification>
        </cac:Item>
        <cac:Price>
<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_SIN_IGV_DET"] . '</cbc:PriceAmount>
        </cac:Price>
    </cac:CreditNoteLine>';
      }
	  if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="20"){
            $xmlCPE = $xmlCPE . '<cac:CreditNoteLine>
        <cbc:ID>' . $detalle[$i]["txtITEM"] . '</cbc:ID>
<cbc:CreditedQuantity unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:CreditedQuantity>
<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:LineExtensionAmount>
        <cac:PricingReference>
            <cac:AlternativeConditionPrice>
<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_DET"] . '</cbc:PriceAmount>
                <cbc:PriceTypeCode>' . $detalle[$i]["txtPRECIO_TIPO_CODIGO"] . '</cbc:PriceTypeCode>
            </cac:AlternativeConditionPrice>
        </cac:PricingReference>
        <cac:TaxTotal>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
            <cac:TaxSubtotal>
<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
                <cac:TaxCategory>
                    <cbc:Percent>0</cbc:Percent>
<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
                    <cac:TaxScheme>
                        <cbc:ID>9997</cbc:ID>
                        <cbc:Name>EXO</cbc:Name>
                        <cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
                    </cac:TaxScheme>
                </cac:TaxCategory>
            </cac:TaxSubtotal>
        </cac:TaxTotal>
        <cac:Item>
<cbc:Description><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtDESCRIPCION_DET"])) ? $detalle[$i]["txtDESCRIPCION_DET"] : "") . ']]></cbc:Description>
            <cac:SellersItemIdentification>
                <cbc:ID><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtCODIGO_DET"])) ? $detalle[$i]["txtCODIGO_DET"] : "") . ']]></cbc:ID>
            </cac:SellersItemIdentification>
        </cac:Item>
        <cac:Price>
<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_SIN_IGV_DET"] . '</cbc:PriceAmount>
        </cac:Price>
    </cac:CreditNoteLine>';
      }
	   if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="30"){
            $xmlCPE = $xmlCPE . '<cac:CreditNoteLine>
        <cbc:ID>' . $detalle[$i]["txtITEM"] . '</cbc:ID>
<cbc:CreditedQuantity unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:CreditedQuantity>
<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:LineExtensionAmount>
        <cac:PricingReference>
            <cac:AlternativeConditionPrice>
<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_DET"] . '</cbc:PriceAmount>
                <cbc:PriceTypeCode>01</cbc:PriceTypeCode>
            </cac:AlternativeConditionPrice>
        </cac:PricingReference>
        <cac:TaxTotal>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
            <cac:TaxSubtotal>
<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
                <cac:TaxCategory>
                    <cbc:Percent>0</cbc:Percent>
<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
                    <cac:TaxScheme>
                        <cbc:ID>9998</cbc:ID>
                        <cbc:Name>INA</cbc:Name>
                        <cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
                    </cac:TaxScheme>
                </cac:TaxCategory>
            </cac:TaxSubtotal>
        </cac:TaxTotal>
        <cac:Item>
<cbc:Description><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtDESCRIPCION_DET"])) ? $detalle[$i]["txtDESCRIPCION_DET"] : "") . ']]></cbc:Description>
            <cac:SellersItemIdentification>
                <cbc:ID><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtCODIGO_DET"])) ? $detalle[$i]["txtCODIGO_DET"] : "") . ']]></cbc:ID>
            </cac:SellersItemIdentification>
        </cac:Item>
        <cac:Price>
<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_SIN_IGV_DET"] . '</cbc:PriceAmount>
        </cac:Price>
    </cac:CreditNoteLine>';
      }
	   if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="31"){
            $xmlCPE = $xmlCPE . '<cac:CreditNoteLine>
        <cbc:ID>' . $detalle[$i]["txtITEM"] . '</cbc:ID>
<cbc:CreditedQuantity unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:CreditedQuantity>
<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:LineExtensionAmount>
        <cac:PricingReference>
            <cac:AlternativeConditionPrice>
<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_DET"] . '</cbc:PriceAmount>
                <cbc:PriceTypeCode>02</cbc:PriceTypeCode>
            </cac:AlternativeConditionPrice>
        </cac:PricingReference>
        <cac:TaxTotal>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
            <cac:TaxSubtotal>
<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
                <cac:TaxCategory>
                    <cbc:Percent>0</cbc:Percent>
<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
                    <cac:TaxScheme>
                        <cbc:ID>9996</cbc:ID>
                        <cbc:Name>GRA</cbc:Name>
                        <cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
                    </cac:TaxScheme>
                </cac:TaxCategory>
            </cac:TaxSubtotal>
        </cac:TaxTotal>
        <cac:Item>
<cbc:Description><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtDESCRIPCION_DET"])) ? $detalle[$i]["txtDESCRIPCION_DET"] : "") . ']]></cbc:Description>
            <cac:SellersItemIdentification>
                <cbc:ID><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtCODIGO_DET"])) ? $detalle[$i]["txtCODIGO_DET"] : "") . ']]></cbc:ID>
            </cac:SellersItemIdentification>
        </cac:Item>
        <cac:Price>
<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_SIN_IGV_DET"] . '</cbc:PriceAmount>
        </cac:Price>
    </cac:CreditNoteLine>';
      }
		
//EXPORTACION			
if ($detalle[$i]["txtCOD_TIPO_OPERACION"] == "40") {
                $xmlCPE = $xmlCPE . '<cac:InvoiceLine>
		<cbc:ID>' . $detalle[$i]["txtITEM"] . '</cbc:ID>
		<cbc:InvoicedQuantity unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '" unitCodeListID="UN/ECE rec 20" unitCodeListAgencyName="United Nations Economic Commission for Europe">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:InvoicedQuantity>
		<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:LineExtensionAmount>
		<cac:PricingReference>
			<cac:AlternativeConditionPrice>
				<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_DET"] . '</cbc:PriceAmount>
				<cbc:PriceTypeCode listName="Tipo de Precio" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo16">' . $detalle[$i]["txtPRECIO_TIPO_CODIGO"] . '</cbc:PriceTypeCode>
			</cac:AlternativeConditionPrice>
		</cac:PricingReference>
		<cac:TaxTotal>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>';

                if ($detalle[$i]["FLG_ICBPER"] > 0) {
                    $xmlCPE = $xmlCPE . '<cac:TaxSubtotal>                                   
                                    <cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["IMPORTE_BP"] . '</cbc:TaxAmount>
                                    <cbc:BaseUnitMeasure unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:BaseUnitMeasure>
                                    <cac:TaxCategory>                                       
                                        <cbc:PerUnitAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["IMPUESTO_BP"] . '</cbc:PerUnitAmount>                                                                                
                                        <cac:TaxScheme>
                                            <cbc:ID schemeAgencyName="PE:SUNAT" schemeName="Codigo de tributos" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo05">7152</cbc:ID>
                                            <cbc:Name>ICBPER</cbc:Name>
                                            <cbc:TaxTypeCode>OTH</cbc:TaxTypeCode>
                                        </cac:TaxScheme>
                                    </cac:TaxCategory>
                                </cac:TaxSubtotal>';
                }

                $xmlCPE = $xmlCPE . '<cac:TaxSubtotal>
				<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
				<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
				<cac:TaxCategory>
					<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">G</cbc:ID>
					<cbc:Percent>0</cbc:Percent>
					<cbc:TaxExemptionReasonCode >' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
					<cac:TaxScheme>
                                                <cbc:ID schemeAgencyName="PE:SUNAT" schemeID="UN/ECE 5153" schemeName="Codigo de tributos">9995</cbc:ID>
						<cbc:Name>EXP</cbc:Name>
						<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
					</cac:TaxScheme>
				</cac:TaxCategory>
			</cac:TaxSubtotal>
		</cac:TaxTotal>
		<cac:Item>
			<cbc:Description><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtDESCRIPCION_DET"])) ? $detalle[$i]["txtDESCRIPCION_DET"] : "") . ']]></cbc:Description>
			<cac:SellersItemIdentification>
				<cbc:ID><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtCODIGO_DET"])) ? $detalle[$i]["txtCODIGO_DET"] : "") . ']]></cbc:ID>
			</cac:SellersItemIdentification>';

	
                if (isset($detalle[$i]["codigosunat"])) {
                        $xmlCPE = $xmlCPE .
                            "<cac:CommodityClassification>
			                    <cbc:ItemClassificationCode listID='UNSPSC' listAgencyName='GS1 US'
			                    listName='Item Classification'>" .$detalle[$i]["codigosunat"]. "</cbc:ItemClassificationCode>
			    </cac:CommodityClassification>";
                }

            if($detalle[$i]["propiedad_adicional"]!=null){
                for ($y = 0; $y < count($detalle[$i]["propiedad_adicional"]); $y++) {
                    $xmlCPE = $xmlCPE .
                            '<cac:AdditionalItemProperty>
                           <cbc:Name>' . $detalle[$i]["propiedad_adicional"][$y]["txtNOMBRE"] . '</cbc:Name>
                           <cbc:NameCode listName="Propiedad del item" listAgencyName="PE:SUNAT" listURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo55">' . $detalle[$i]["propiedad_adicional"][$y]["txtCODIGO"] . '</cbc:NameCode>
                           <cbc:Value>' . $detalle[$i]["propiedad_adicional"][$y]["txtVALOR"] . '</cbc:Value>
                       </cac:AdditionalItemProperty>';
                }
            }

                $xmlCPE = $xmlCPE .
                        '</cac:Item>
		<cac:Price>
			<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_SIN_IGV_DET"] . '</cbc:PriceAmount>
		</cac:Price>
	</cac:InvoiceLine>';
            }
		
		
    }

    $xmlCPE = $xmlCPE . '</CreditNote>';
    $doc->loadXML($xmlCPE);
    $doc->save(dirname(__FILE__) . '/' . $ruta . '.XML');

    return '1';
}

function cpeND($ruta, $cabecera, $detalle) {
    $doc = new DOMDocument();
    $doc->formatOutput = FALSE;
    $doc->preserveWhiteSpace = TRUE;
    $doc->encoding = 'utf-8';
    //$doc->encoding = 'ISO-8859-1';
    //$doc->encoding = 'utf-8';
    $xmlCPE = '<?xml version="1.0" encoding="UTF-8"?>
<DebitNote xmlns="urn:oasis:names:specification:ubl:schema:xsd:DebitNote-2" xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" xmlns:ccts="urn:un:unece:uncefact:documentation:2" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2" xmlns:qdt="urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2" xmlns:sac="urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1" xmlns:udt="urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <ext:UBLExtensions>
        <ext:UBLExtension>
            <ext:ExtensionContent>
            </ext:ExtensionContent>
        </ext:UBLExtension>
    </ext:UBLExtensions>
    <cbc:UBLVersionID>2.1</cbc:UBLVersionID>
    <cbc:CustomizationID>2.0</cbc:CustomizationID>
    <cbc:ID>' . $cabecera["NRO_COMPROBANTE"] . '</cbc:ID>
    <cbc:IssueDate>' . $cabecera["FECHA_DOCUMENTO"] . '</cbc:IssueDate>
    <cbc:IssueTime>00:00:00</cbc:IssueTime>
    <cbc:DocumentCurrencyCode>' . $cabecera["COD_MONEDA"] . '</cbc:DocumentCurrencyCode>
    <cac:DiscrepancyResponse>
        <cbc:ReferenceID>' . $cabecera["NRO_DOCUMENTO_MODIFICA"] . '</cbc:ReferenceID>
        <cbc:ResponseCode>' . $cabecera["COD_TIPO_MOTIVO"] . '</cbc:ResponseCode>
        <cbc:Description><![CDATA[' . $cabecera["DESCRIPCION_MOTIVO"] . ']]></cbc:Description>
    </cac:DiscrepancyResponse>
    <cac:BillingReference>
        <cac:InvoiceDocumentReference>
            <cbc:ID>' . $cabecera["NRO_DOCUMENTO_MODIFICA"] . '</cbc:ID>
            <cbc:DocumentTypeCode>' . $cabecera["TIPO_COMPROBANTE_MODIFICA"] . '</cbc:DocumentTypeCode>
        </cac:InvoiceDocumentReference>
    </cac:BillingReference>
    <cac:Signature>
        <cbc:ID>IDSignST</cbc:ID>
        <cac:SignatoryParty>
            <cac:PartyIdentification>
                <cbc:ID>' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
            </cac:PartyIdentification>
            <cac:PartyName>
                <cbc:Name><![CDATA[' . $cabecera["RAZON_SOCIAL_EMPRESA"] . ']]></cbc:Name>
            </cac:PartyName>
        </cac:SignatoryParty>
        <cac:DigitalSignatureAttachment>
            <cac:ExternalReference>
                <cbc:URI>#SignatureSP</cbc:URI>
            </cac:ExternalReference>
        </cac:DigitalSignatureAttachment>
    </cac:Signature>
    <cac:AccountingSupplierParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_EMPRESA"] . '" >' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
            </cac:PartyIdentification>
            <cac:PartyName>
                <cbc:Name><![CDATA[' . $cabecera["NOMBRE_COMERCIAL_EMPRESA"] . ']]></cbc:Name>
            </cac:PartyName>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName><![CDATA[' . $cabecera["RAZON_SOCIAL_EMPRESA"] . ']]></cbc:RegistrationName>
                <cac:RegistrationAddress>
                    <cbc:AddressTypeCode>' . $cabecera["IDSUNAT"] . '</cbc:AddressTypeCode>
                </cac:RegistrationAddress>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingSupplierParty>
    <cac:AccountingCustomerParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_CLIENTE"] . '" >' . $cabecera["NRO_DOCUMENTO_CLIENTE"] . '</cbc:ID>
            </cac:PartyIdentification>
            <cac:PartyLegalEntity>
<cbc:RegistrationName><![CDATA[' . $cabecera["RAZON_SOCIAL_CLIENTE"] . ']]></cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingCustomerParty>';
    
    
	$xmlCPE = $xmlCPE .
                '<cac:TaxTotal>
        <cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_IGV"] . '</cbc:TaxAmount>
        <cac:TaxSubtotal>
<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_GRAVADAS"] . '</cbc:TaxableAmount>
<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_IGV"] . '</cbc:TaxAmount>
            <cac:TaxCategory>
                <cac:TaxScheme>
                    <cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">1000</cbc:ID>
                    <cbc:Name>IGV</cbc:Name>
                    <cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
                </cac:TaxScheme>
            </cac:TaxCategory>
        </cac:TaxSubtotal>';
        
        
if ($cabecera["TOTAL_EXONERADAS"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_EXONERADAS"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0.00</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">E</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9997</cbc:ID>
					<cbc:Name>EXO</cbc:Name>
					<cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
	
}

if ($cabecera["TOTAL_ISC"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_ISC"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_ISC"] . '</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">S</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">2000</cbc:ID>
					<cbc:Name>ISC</cbc:Name>
					<cbc:TaxTypeCode>EXC</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        //CAMPO NUEVO
        if ($cabecera["TOTAL_EXPORTACION"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_EXPORTACION"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0.00</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">G</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9995</cbc:ID>
					<cbc:Name>EXP</cbc:Name>
					<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_GRATUITAS"] > 0) {
            $igvGratuitas = isset($cabecera["TOTAL_IGV_GRATUITAS"]) ? $cabecera["TOTAL_IGV_GRATUITAS"] : '0.00';
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_GRATUITAS"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $igvGratuitas . '</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">Z</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9996</cbc:ID>
					<cbc:Name>GRA</cbc:Name>
					<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_EXONERADAS"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_EXONERADAS"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0.00</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">E</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9997</cbc:ID>
					<cbc:Name>EXO</cbc:Name>
					<cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_INAFECTA"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_INAFECTA"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0.00</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">O</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9998</cbc:ID>
					<cbc:Name>INA</cbc:Name>
					<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }
        if ($cabecera["TOTAL_OTR_IMP"] > 0) {
            $xmlCPE = $xmlCPE .
                    '<cac:TaxSubtotal>
			<cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_OTR_IMP"] . '</cbc:TaxableAmount>
			<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL_OTR_IMP"] . '</cbc:TaxAmount>
			<cac:TaxCategory>
				<cbc:ID schemeID="UN/ECE 5305" schemeName="Tax Category Identifier" schemeAgencyName="United Nations Economic Commission for Europe">S</cbc:ID>
				<cac:TaxScheme>
					<cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">9999</cbc:ID>
					<cbc:Name>OTR</cbc:Name>
					<cbc:TaxTypeCode>OTH</cbc:TaxTypeCode>
				</cac:TaxScheme>
			</cac:TaxCategory>
		</cac:TaxSubtotal>';
        }



        
$xmlCPE = $xmlCPE .' </cac:TaxTotal>
    <cac:RequestedMonetaryTotal>
<cbc:PayableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $cabecera["TOTAL"] . '</cbc:PayableAmount>
    </cac:RequestedMonetaryTotal>';






    for ($i = 0; $i < count($detalle); $i++) {
        $xmlCPE = $xmlCPE . '
    <cac:DebitNoteLine>
        <cbc:ID>' . $detalle[$i]["txtITEM"] . '</cbc:ID>
<cbc:DebitedQuantity unitCode="' . $detalle[$i]["txtUNIDAD_MEDIDA_DET"] . '">' . $detalle[$i]["txtCANTIDAD_DET"] . '</cbc:DebitedQuantity>
<cbc:LineExtensionAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:LineExtensionAmount>
        <cac:PricingReference>
            <cac:AlternativeConditionPrice>
<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_DET"] . '</cbc:PriceAmount>
<cbc:PriceTypeCode>' . $detalle[$i]["txtPRECIO_TIPO_CODIGO"] . '</cbc:PriceTypeCode>
            </cac:AlternativeConditionPrice>
        </cac:PricingReference>
        <cac:TaxTotal>';	
if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="10"){

$xmlCPE = $xmlCPE . '<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
            <cac:TaxSubtotal>
                <cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
                <cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIGV"] . '</cbc:TaxAmount>
                <cac:TaxCategory>
				<cbc:Percent>' . $cabecera["POR_IGV"] . '</cbc:Percent>		
				<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
                    <cac:TaxScheme>
                        <cbc:ID>1000</cbc:ID>
                        <cbc:Name>IGV</cbc:Name>
                        <cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
						</cac:TaxScheme>';
}


if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="20"){

$xmlCPE = $xmlCPE . '<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
            <cac:TaxSubtotal>
                <cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
                <cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
                <cac:TaxCategory>
				<cbc:Percent>0</cbc:Percent>
<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
                    <cac:TaxScheme>
                        <cbc:ID>9997</cbc:ID>
                        <cbc:Name>EXO</cbc:Name>
                        <cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
                    </cac:TaxScheme>
				
				';	
	
}

if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="30"){

$xmlCPE = $xmlCPE . '<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
            <cac:TaxSubtotal>
                <cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
                <cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
                <cac:TaxCategory>
				<cbc:Percent>0</cbc:Percent>
<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
                    <cac:TaxScheme>
                        <cbc:ID>9998</cbc:ID>
                        <cbc:Name>INA</cbc:Name>
                        <cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
                    </cac:TaxScheme>
				
				';	
	
}

if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="31"){

$xmlCPE = $xmlCPE . '<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
            <cac:TaxSubtotal>
                <cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
                <cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
                <cac:TaxCategory>
				<cbc:Percent>0</cbc:Percent>
<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
                    <cac:TaxScheme>
                        <cbc:ID>9996</cbc:ID>
                        <cbc:Name>GRA</cbc:Name>
                        <cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
                    </cac:TaxScheme>
				
				';	
	
}


if($detalle[$i]["txtCOD_TIPO_OPERACION"]=="40"){

$xmlCPE = $xmlCPE . '<cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
            <cac:TaxSubtotal>
                <cbc:TaxableAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtIMPORTE_DET"] . '</cbc:TaxableAmount>
                <cbc:TaxAmount currencyID="' . $cabecera["COD_MONEDA"] . '">0</cbc:TaxAmount>
                <cac:TaxCategory>
				<cbc:Percent>0</cbc:Percent>
<cbc:TaxExemptionReasonCode>' . $detalle[$i]["txtCOD_TIPO_OPERACION"] . '</cbc:TaxExemptionReasonCode>
					<cac:TaxScheme>
<cbc:ID>9995</cbc:ID>
						<cbc:Name>EXP</cbc:Name>
						<cbc:TaxTypeCode>FRE</cbc:TaxTypeCode>
					</cac:TaxScheme>
				
				';	
	
}

$xmlCPE = $xmlCPE . '</cac:TaxCategory>
            </cac:TaxSubtotal>
        </cac:TaxTotal>
		
<cac:Item>
<cbc:Description><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtDESCRIPCION_DET"])) ? $detalle[$i]["txtDESCRIPCION_DET"] : "") . ']]></cbc:Description>
            <cac:SellersItemIdentification>
                <cbc:ID><![CDATA[' . ValidarCaracteresInv((isset($detalle[$i]["txtCODIGO_DET"])) ? $detalle[$i]["txtCODIGO_DET"] : "") . ']]></cbc:ID>
            </cac:SellersItemIdentification>
        </cac:Item>
<cac:Price>
<cbc:PriceAmount currencyID="' . $cabecera["COD_MONEDA"] . '">' . $detalle[$i]["txtPRECIO_SIN_IGV_DET"] . '</cbc:PriceAmount>
</cac:Price>
    </cac:DebitNoteLine>';
    }

    $xmlCPE = $xmlCPE . '</DebitNote>';
    $doc->loadXML($xmlCPE);
    $doc->save(dirname(__FILE__) . '/' . $ruta . '.XML');

    return '1';
}
 
function cpePERCEP($ruta, $cabecera, $detalle) {
    $doc = new DOMDocument();
    $doc->formatOutput = FALSE;
    $doc->preserveWhiteSpace = TRUE;
    $doc->encoding = 'ISO-8859-1';
    //$doc->encoding = 'ISO-8859-1';
    //$doc->encoding = 'utf-8';
    $xmlCPE = '<?xml version="1.0" encoding="UTF-8"?><Perception xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:qdt="urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2" xmlns:sac="urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1" xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2" xmlns:udt="urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2" xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" xmlns:ccts="urn:un:unece:uncefact:documentation:2" xmlns="urn:sunat:names:specification:ubl:peru:schema:xsd:Perception-1">
<ext:UBLExtensions>
<ext:UBLExtension>
<ext:ExtensionContent>
</ext:ExtensionContent>
</ext:UBLExtension>
</ext:UBLExtensions>
<cbc:UBLVersionID>2.0</cbc:UBLVersionID>
<cbc:CustomizationID>1.0</cbc:CustomizationID>
<cac:Signature>
<cbc:ID>' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
<cac:SignatoryParty>
		<cac:PartyIdentification>
		<cbc:ID>' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
		</cac:PartyIdentification>
		<cac:PartyName><cbc:Name><![CDATA[' . $cabecera["RAZON_SOCIAL_EMPRESA"] . ']]></cbc:Name></cac:PartyName>
		</cac:SignatoryParty>
<cac:DigitalSignatureAttachment>
<cac:ExternalReference><cbc:URI>#IDSignKG</cbc:URI></cac:ExternalReference>
</cac:DigitalSignatureAttachment>
</cac:Signature>
	<cbc:ID>' . $cabecera["NRO_COMPROBANTE"] . '</cbc:ID>
	<cbc:IssueDate>' . $cabecera["FECHA_DOCUMENTO"] . '</cbc:IssueDate>
<cbc:IssueTime>00:00:00</cbc:IssueTime>
	';
	
if($cabecera["REGULAR"]=='01'){	
$xmlCPE = $xmlCPE . '<sac:ExceptionalIndicator>01</sac:ExceptionalIndicator>';
}

$xmlCPE = $xmlCPE . '
	<cac:AgentParty>
		<cac:PartyIdentification>
			<cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_EMPRESA"] . '">' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
		</cac:PartyIdentification>
		<cac:PartyName><cbc:Name><![CDATA[' . $cabecera["NOMBRE_COMERCIAL_EMPRESA"] . ']]></cbc:Name></cac:PartyName>
		<cac:PostalAddress>
			<cbc:ID>' . $cabecera["CODIGO_UBIGEO_EMPRESA"] . '</cbc:ID>
			<cbc:StreetName><![CDATA[' . $cabecera["DIRECCION_EMPRESA"] . ']]></cbc:StreetName>
			<cbc:CityName>' . $cabecera["DEPARTAMENTO_EMPRESA"] . '</cbc:CityName>
			<cbc:CountrySubentity>' . $cabecera["PROVINCIA_EMPRESA"] . '</cbc:CountrySubentity>
			<cbc:District>' . $cabecera["DISTRITO_EMPRESA"] . '</cbc:District>
<cac:Country><cbc:IdentificationCode>' . $cabecera["CODIGO_PAIS_EMPRESA"] . '</cbc:IdentificationCode></cac:Country>
		</cac:PostalAddress>
		<cac:PartyLegalEntity>
			<cbc:RegistrationName><![CDATA[' . $cabecera["RAZON_SOCIAL_EMPRESA"] . ']]></cbc:RegistrationName>
		</cac:PartyLegalEntity>
	</cac:AgentParty>';

    for ($i = 0; $i < count($detalle); $i++) {
        $xmlCPE = $xmlCPE . '<cac:ReceiverParty>
    <cac:PartyIdentification>
      <cbc:ID schemeID="' . $detalle[$i]["TIPO_DOCUMENTO_CLIENTE"] . '">' . $detalle[$i]["NRO_DOCUMENTO_CLIENTE"] . '</cbc:ID>
    </cac:PartyIdentification>
    <cac:PartyLegalEntity>
      <cbc:RegistrationName><![CDATA[' .$detalle[$i]["RAZON_SOCIAL_CLIENTE"] . ']]></cbc:RegistrationName>
    </cac:PartyLegalEntity>
  </cac:ReceiverParty>
  <sac:SUNATPerceptionSystemCode>' .$detalle[$i]["CODIGO_PERCEPCION"] . '</sac:SUNATPerceptionSystemCode>
  <sac:SUNATPerceptionPercent>' .$detalle[$i]["TASA"] . '</sac:SUNATPerceptionPercent>
  <cbc:Note><![CDATA[' .$detalle[$i]["DETALLE"] . ']]></cbc:Note>
  <cbc:TotalInvoiceAmount currencyID="' .$detalle[$i]["MONEDA"] . '">' .$detalle[$i]["PERCEPCION"] . '</cbc:TotalInvoiceAmount>
  <sac:SUNATTotalCashed currencyID="' .$detalle[$i]["MONEDA"] . '">' .$detalle[$i]["TOTAL"] . '</sac:SUNATTotalCashed>
  <sac:SUNATPerceptionDocumentReference>
    <cbc:ID schemeID="' .$detalle[$i]["TIPODOC"] . '">' .$detalle[$i]["SERIE"] . '</cbc:ID>
    <cbc:IssueDate>' .$detalle[$i]["FECHA"] . '</cbc:IssueDate>
    <cbc:TotalInvoiceAmount currencyID="' .$detalle[$i]["MONEDA"] . '">' .$detalle[$i]["SUBTOTAL"] . '</cbc:TotalInvoiceAmount>
    <cac:Payment>
      <cbc:ID>' .$detalle[$i]["txtITEM"] . '</cbc:ID>
      <cbc:PaidAmount currencyID="' .$detalle[$i]["MONEDA"] . '">' .$detalle[$i]["SUBTOTAL"] . '</cbc:PaidAmount>
      <cbc:PaidDate>' .$detalle[$i]["FECHA"] . '</cbc:PaidDate>
    </cac:Payment>
    <sac:SUNATPerceptionInformation>
      <sac:SUNATPerceptionAmount currencyID="' .$detalle[$i]["MONEDA"] . '">' .$detalle[$i]["PERCEPCION"] . '</sac:SUNATPerceptionAmount>
      <sac:SUNATPerceptionDate>' .$detalle[$i]["FECHA"] . '</sac:SUNATPerceptionDate>
      <sac:SUNATNetTotalCashed currencyID="' .$detalle[$i]["MONEDA"] . '">' .$detalle[$i]["TOTAL"] . '</sac:SUNATNetTotalCashed>
      <cac:ExchangeRate>
        <cbc:SourceCurrencyCode>' .$detalle[$i]["MONEDA"] . '</cbc:SourceCurrencyCode>
        <cbc:TargetCurrencyCode>' .$detalle[$i]["MONEDA"] . '</cbc:TargetCurrencyCode>
        <cbc:CalculationRate>' .$detalle[$i]["txtITEM"] . '</cbc:CalculationRate>
        <cbc:Date>' .$detalle[$i]["FECHA"] . '</cbc:Date>
      </cac:ExchangeRate>
    </sac:SUNATPerceptionInformation>
  </sac:SUNATPerceptionDocumentReference>
';
    }

    $xmlCPE = $xmlCPE . '</Perception>';
    $doc->loadXML($xmlCPE);
    $doc->save(dirname(__FILE__) . '/' . $ruta . '.XML');

    return '1';
}


function cpeBajaSunat($ruta, $cabecera, $detalle) {
    $doc = new DOMDocument();
    $doc->formatOutput = FALSE;
    $doc->preserveWhiteSpace = TRUE;
    $doc->encoding = 'ISO-8859-1';
    $xmlCPE = '<?xml version="1.0" encoding="ISO-8859-1" standalone="no"?><VoidedDocuments xmlns="urn:sunat:names:specification:ubl:peru:schema:xsd:VoidedDocuments-1" xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2" xmlns:sac="urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<ext:UBLExtensions>
<ext:UBLExtension>
<ext:ExtensionContent>
</ext:ExtensionContent>
</ext:UBLExtension>
</ext:UBLExtensions>
<cbc:UBLVersionID>2.0</cbc:UBLVersionID>
<cbc:CustomizationID>1.0</cbc:CustomizationID>
<cbc:ID>' . $cabecera["CODIGO"] . '-' . $cabecera["SERIE"] . '-' . $cabecera["SECUENCIA"] . '</cbc:ID>
<cbc:ReferenceDate>' . $cabecera["FECHA_REFERENCIA"] . '</cbc:ReferenceDate>
<cbc:IssueDate>' . $cabecera["FECHA_BAJA"] . '</cbc:IssueDate>
<cac:Signature>
<cbc:ID>IDSignKG</cbc:ID>
<cac:SignatoryParty>
<cac:PartyIdentification>
<cbc:ID>' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
</cac:PartyIdentification>
<cac:PartyName>
<cbc:Name>' . ValidarCaracteresInv($cabecera["RAZON_SOCIAL"]) . '</cbc:Name>
</cac:PartyName>
</cac:SignatoryParty>
<cac:DigitalSignatureAttachment>
<cac:ExternalReference>
<cbc:URI>#' . $cabecera["SERIE"] . '-' . $cabecera["SECUENCIA"] . '</cbc:URI>
</cac:ExternalReference>
</cac:DigitalSignatureAttachment>
</cac:Signature>
<cac:AccountingSupplierParty>
<cbc:CustomerAssignedAccountID>' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:CustomerAssignedAccountID>
<cbc:AdditionalAccountID>' . $cabecera["TIPO_DOCUMENTO"] . '</cbc:AdditionalAccountID>
<cac:Party>
<cac:PartyLegalEntity>
<cbc:RegistrationName><![CDATA[' . ValidarCaracteresInv($cabecera["RAZON_SOCIAL"]) . ']]></cbc:RegistrationName>
</cac:PartyLegalEntity>
</cac:Party>
</cac:AccountingSupplierParty>';

    for ($i = 0; $i < count($detalle); $i++) {
        $xmlCPE = $xmlCPE . '<sac:VoidedDocumentsLine>
<cbc:LineID>' . $detalle[$i]["ITEM"] . '</cbc:LineID>
<cbc:DocumentTypeCode>' . $detalle[$i]["TIPO_COMPROBANTE"] . '</cbc:DocumentTypeCode>
<sac:DocumentSerialID>' . $detalle[$i]["SERIE"] . '</sac:DocumentSerialID>
<sac:DocumentNumberID>' . $detalle[$i]["NUMERO"] . '</sac:DocumentNumberID>
<sac:VoidReasonDescription><![CDATA[' . ValidarCaracteresInv($detalle[$i]["DESCRIPCION"]) . ']]></sac:VoidReasonDescription>
</sac:VoidedDocumentsLine>';
    }
    $xmlCPE = $xmlCPE . '</VoidedDocuments>';

    $doc->loadXML($xmlCPE);
    $doc->save(dirname(__FILE__) . '/' . $ruta . '.XML');

    return 'XML BAJA CREADO';
}

function cpeResumenBoleta($ruta, $cabecera, $detalle) {
    $doc = new DOMDocument();
    $doc->formatOutput = FALSE;
    $doc->preserveWhiteSpace = TRUE;
    $doc->encoding = 'ISO-8859-1';
    $xmlCPE = '<?xml version="1.0" encoding="iso-8859-1" standalone="no"?>
    <SummaryDocuments 
	xmlns="urn:sunat:names:specification:ubl:peru:schema:xsd:SummaryDocuments-1" 
	xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" 
	xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" 
	xmlns:ds="http://www.w3.org/2000/09/xmldsig#" 
	xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2" 
	xmlns:sac="urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1"
	xmlns:qdt="urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2" 
	xmlns:udt="urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2">
	<ext:UBLExtensions>
		<ext:UBLExtension>
                        <ext:ExtensionContent>
			</ext:ExtensionContent>
		</ext:UBLExtension>
	</ext:UBLExtensions>
	<cbc:UBLVersionID>2.0</cbc:UBLVersionID>
	<cbc:CustomizationID>1.1</cbc:CustomizationID>
	<cbc:ID>' . $cabecera["CODIGO"] . '-' . $cabecera["SERIE"] . '-' . $cabecera["SECUENCIA"] . '</cbc:ID>
	<cbc:ReferenceDate>' . $cabecera["FECHA_REFERENCIA"] . '</cbc:ReferenceDate>
	<cbc:IssueDate>' . $cabecera["FECHA_DOCUMENTO"] . '</cbc:IssueDate>
	<cac:Signature>
		<cbc:ID>' . $cabecera["CODIGO"] . '-' . $cabecera["SERIE"] . '-' . $cabecera["SECUENCIA"] . '</cbc:ID>
		<cac:SignatoryParty>
			<cac:PartyIdentification>
				<cbc:ID>' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
			</cac:PartyIdentification>
			<cac:PartyName>
				<cbc:Name>' . $cabecera["RAZON_SOCIAL"] . '</cbc:Name>
			</cac:PartyName>
		</cac:SignatoryParty>
		<cac:DigitalSignatureAttachment>
			<cac:ExternalReference>
				<cbc:URI>' . $cabecera["CODIGO"] . '-' . $cabecera["SERIE"] . '-' . $cabecera["SECUENCIA"] . '</cbc:URI>
			</cac:ExternalReference>
		</cac:DigitalSignatureAttachment>
	</cac:Signature>
	<cac:AccountingSupplierParty>
		<cbc:CustomerAssignedAccountID>' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:CustomerAssignedAccountID>
		<cbc:AdditionalAccountID>' . $cabecera["TIPO_DOCUMENTO"] . '</cbc:AdditionalAccountID>
		<cac:Party>
			<cac:PartyLegalEntity>
				<cbc:RegistrationName>' . $cabecera["RAZON_SOCIAL"] . '</cbc:RegistrationName>
			</cac:PartyLegalEntity>
		</cac:Party>
	</cac:AccountingSupplierParty>';
    /*
      private int ITEM;
      private String TIPO_COMPROBANTE;
      private String NRO_COMPROBANTE;
      private String TIPO_DOCUMENTO;
      private String NRO_DOCUMENTO;
      private String TIPO_COMPROBANTE_REF;
      private String NRO_COMPROBANTE_REF;
      private String STATU;
      private String COD_MONEDA;
      private double TOTAL;
      private double GRAVADA;
      private double ISC;
      private double IGV;
      private double OTROS;
      private int CARGO_X_ASIGNACION;
      private double MONTO_CARGO_X_ASIG;
      private String COD_TIPO_IMPORTE1;
      private double EXONERADO;
      private String COD_TIPO_IMPORTE2;
      private double INAFECTO;
      private String COD_TIPO_IMPORTE3;
      private double EXPORTACION;
      private String COD_TIPO_IMPORTE4;
      private double GRATUITAS;
      private String COD_TIPO_IMPORTE5;
      private String ESTADOS;
     */
    for ($i = 0; $i < count($detalle); $i++) {
        $xmlCPE = $xmlCPE . '<sac:SummaryDocumentsLine>
		<cbc:LineID>' . $detalle[$i]["ITEM"] . '</cbc:LineID>
		<cbc:DocumentTypeCode>' . $detalle[$i]["TIPO_COMPROBANTE"] . '</cbc:DocumentTypeCode>
		<cbc:ID>' . $detalle[$i]["NRO_COMPROBANTE"] . '</cbc:ID>
		<cac:AccountingCustomerParty>
			<cbc:CustomerAssignedAccountID>' . $detalle[$i]["NRO_DOCUMENTO"] . '</cbc:CustomerAssignedAccountID>
			<cbc:AdditionalAccountID>' . $detalle[$i]["TIPO_DOCUMENTO"] . '</cbc:AdditionalAccountID>
		</cac:AccountingCustomerParty>';
        if ($detalle[$i]["TIPO_COMPROBANTE"] == "07" || $detalle[$i]["TIPO_COMPROBANTE"] == "08") {
            $xmlCPE = $xmlCPE . '<cac:BillingReference>
			<cac:InvoiceDocumentReference>
				<cbc:ID>' . $detalle[$i]["NRO_COMPROBANTE_REF"] . '</cbc:ID>
				<cbc:DocumentTypeCode>' . $detalle[$i]["TIPO_COMPROBANTE_REF"] . '</cbc:DocumentTypeCode>
			</cac:InvoiceDocumentReference>
		</cac:BillingReference>';
        }
        $xmlCPE = $xmlCPE . '<cac:Status>
			<cbc:ConditionCode>' . $detalle[$i]["STATU"] . '</cbc:ConditionCode>
		</cac:Status>                
		<sac:TotalAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["TOTAL"] . '</sac:TotalAmount>
		
                <sac:BillingPayment>
			<cbc:PaidAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["GRAVADA"] . '</cbc:PaidAmount>
			<cbc:InstructionID>01</cbc:InstructionID>
		</sac:BillingPayment>';

        if ($detalle[$i]["EXONERADO"] > 0) {
            $xmlCPE = $xmlCPE . '<sac:BillingPayment>
			<cbc:PaidAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["EXONERADO"] . '</cbc:PaidAmount>
			<cbc:InstructionID>02</cbc:InstructionID>
		</sac:BillingPayment>';
        }

        if ($detalle[$i]["INAFECTO"] > 0) {
            $xmlCPE = $xmlCPE . '<sac:BillingPayment>
			<cbc:PaidAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["INAFECTO"] . '</cbc:PaidAmount>
			<cbc:InstructionID>03</cbc:InstructionID>
		</sac:BillingPayment>';
        }

        if ($detalle[$i]["EXPORTACION"] > 0) {
            $xmlCPE = $xmlCPE . '<sac:BillingPayment>
			<cbc:PaidAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["EXPORTACION"] . '</cbc:PaidAmount>
			<cbc:InstructionID>04</cbc:InstructionID>
		</sac:BillingPayment>';
        }

        if ($detalle[$i]["GRATUITAS"] > 0) {
            $xmlCPE = $xmlCPE . '<sac:BillingPayment>
			<cbc:PaidAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["GRATUITAS"] . '</cbc:PaidAmount>
			<cbc:InstructionID>05</cbc:InstructionID>
		</sac:BillingPayment>';
        }

        if ($detalle[$i]["MONTO_CARGO_X_ASIG"] > 0) {
            $xmlCPE = $xmlCPE . '<cac:AllowanceCharge>';
            if ($detalle[$i]["CARGO_X_ASIGNACION"] == 1) {
                $xmlCPE = $xmlCPE . '<cbc:ChargeIndicator>true</cbc:ChargeIndicator>';
            } else {
                $xmlCPE = $xmlCPE . '<cbc:ChargeIndicator>false</cbc:ChargeIndicator>';
            }
            $xmlCPE = $xmlCPE . '<cbc:Amount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["MONTO_CARGO_X_ASIG"] . '</cbc:Amount>
                    </cac:AllowanceCharge>';
        }
        if ($detalle[$i]["ISC"] > 0) {
            $xmlCPE = $xmlCPE . '<cac:TaxTotal>
			<cbc:TaxAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["ISC"] . '</cbc:TaxAmount>
			<cac:TaxSubtotal>
				<cbc:TaxAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["ISC"] . '</cbc:TaxAmount>
				<cac:TaxCategory>
					<cac:TaxScheme>
						<cbc:ID>2000</cbc:ID>
						<cbc:Name>ISC</cbc:Name>
						<cbc:TaxTypeCode>EXC</cbc:TaxTypeCode>
					</cac:TaxScheme>
				</cac:TaxCategory>
			</cac:TaxSubtotal>
		</cac:TaxTotal>';
        }
        $xmlCPE = $xmlCPE . '<cac:TaxTotal>
			<cbc:TaxAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["IGV"] . '</cbc:TaxAmount>
			<cac:TaxSubtotal>
				<cbc:TaxAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["IGV"] . '</cbc:TaxAmount>
				<cac:TaxCategory>
					<cac:TaxScheme>
						<cbc:ID>1000</cbc:ID>
						<cbc:Name>IGV</cbc:Name>
						<cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>
					</cac:TaxScheme>
				</cac:TaxCategory>
			</cac:TaxSubtotal>
		</cac:TaxTotal>';

        if ($detalle[$i]["OTROS"] > 0) {
            $xmlCPE = $xmlCPE . '<cac:TaxTotal>
			<cbc:TaxAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["OTROS"] . '</cbc:TaxAmount>
			<cac:TaxSubtotal>
				<cbc:TaxAmount currencyID="' . $detalle[$i]["COD_MONEDA"] . '">' . $detalle[$i]["OTROS"] . '</cbc:TaxAmount>
				<cac:TaxCategory>
					<cac:TaxScheme>
						<cbc:ID>9999</cbc:ID>
						<cbc:Name>OTROS</cbc:Name>
						<cbc:TaxTypeCode>OTH</cbc:TaxTypeCode>
					</cac:TaxScheme>
				</cac:TaxCategory>
			</cac:TaxSubtotal>
		</cac:TaxTotal>';
        }
        $xmlCPE = $xmlCPE . '</sac:SummaryDocumentsLine>';
    }
    $xmlCPE = $xmlCPE . '</SummaryDocuments>';

    $doc->loadXML($xmlCPE);
    $doc->save(dirname(__FILE__) . '/' . $ruta . '.XML');

    return 'XML RESUMEN BOLETA CREADO';
}

function cpeGuia($ruta, $cabecera, $detalle) {
$doc = new DOMDocument();
    $doc->formatOutput = FALSE;
    $doc->preserveWhiteSpace = TRUE;
	/*
    $doc->encoding = 'ISO-8859-1';
    $xmlCPE = '<?xml version="1.0" encoding="iso-8859-1"?>
	*/
	
$doc->encoding = 'utf-8';
$xmlCPE = '<?xml version="1.0" encoding="utf-8"?>
<DespatchAdvice xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:tci="http://tempuri.org/" xmlns:qdt="urn:oasis:names:specification:ubl:schema:xsd:QualifiedDataTypes-2" xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2" xmlns:udt="urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" xmlns:sac="urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1" xmlns:ccts="urn:un:unece:uncefact:documentation:2" xmlns="urn:oasis:names:specification:ubl:schema:xsd:DespatchAdvice-2">
	<ext:UBLExtensions>
		<ext:UBLExtension>
			<ext:ExtensionContent>
			</ext:ExtensionContent>
		</ext:UBLExtension>
	</ext:UBLExtensions>
	<cbc:UBLVersionID>2.1</cbc:UBLVersionID>
	<cbc:CustomizationID>2.0</cbc:CustomizationID>
<cbc:ID>' . $cabecera["SERIE"] . '-' . $cabecera["SECUENCIA"] . '</cbc:ID>
<cbc:IssueDate>' . $cabecera["FECHA_DOCUMENTO"] . '</cbc:IssueDate>
<cbc:IssueTime>00:00:00</cbc:IssueTime>
<cbc:DespatchAdviceTypeCode>' . $cabecera["CODIGO"] . '</cbc:DespatchAdviceTypeCode>
<cbc:Note>' . $cabecera["NOTA"] . '</cbc:Note>';

$xmlCPE = $xmlCPE .
                '	
<cac:Signature>
    <cbc:ID  schemeID="' . $cabecera["TIPO_DOCUMENTO_EMPRESA"] . '" schemeName="Documento de Identidad" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06" >' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
    <cac:SignatoryParty>
      <cac:PartyIdentification>
<cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_EMPRESA"] . '" schemeName="Documento de Identidad" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06">' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
      </cac:PartyIdentification>
      <cac:PartyName>
        <cbc:Name><![CDATA[' . ValidarCaracteresInv($cabecera["RAZON_SOCIAL"]) . ']]></cbc:Name>
      </cac:PartyName>
    </cac:SignatoryParty>
    <cac:DigitalSignatureAttachment>
      <cac:ExternalReference>
        <cbc:URI  schemeID="6" schemeName="Documento de Identidad" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06" >' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:URI>
      </cac:ExternalReference>
    </cac:DigitalSignatureAttachment>
  </cac:Signature>	
	';

$xmlCPE = $xmlCPE .
                '<cac:DespatchSupplierParty>
<cbc:CustomerAssignedAccountID schemeID="' . $cabecera["TIPO_DOCUMENTO_EMPRESA"] . '  ">' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:CustomerAssignedAccountID>
<cac:Party>
<cac:PartyIdentification>
<cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_EMPRESA"] . '" schemeName="Documento de Identidad" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06">' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '</cbc:ID>
</cac:PartyIdentification>

<cac:PartyLegalEntity>
<cbc:RegistrationName><![CDATA[' .ValidarCaracteresInv($cabecera["RAZON_SOCIAL"]). ']]></cbc:RegistrationName>
</cac:PartyLegalEntity>

</cac:Party>
</cac:DespatchSupplierParty>

 <!-- DATOS DEL RECEPTOR (DESTINATARIO) -->
<cac:DeliveryCustomerParty>
	<cac:Party>
		<cac:PartyIdentification>
		<cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_CLIENTE"] . '" schemeName="Documento de Identidad" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06">' . $cabecera["NRO_DOCUMENTO_CLIENTE"] . '</cbc:ID>
		</cac:PartyIdentification>
		<cac:PartyLegalEntity><cbc:RegistrationName><![CDATA[' . ValidarCaracteresInv($cabecera["RAZON_SOCIAL_CLIENTE"]) . ']]></cbc:RegistrationName></cac:PartyLegalEntity></cac:Party>
</cac:DeliveryCustomerParty>
 <!-- DATOS DEL RECEPTOR (DESTINATARIO) -->
 
<cac:Shipment>
        <cbc:ID>1</cbc:ID>
        <cbc:HandlingCode>' . $cabecera["CODMOTIVO_TRASLADO"] . '</cbc:HandlingCode>';
        
        
if($cabecera["MOTIVO_TRASLADO"]=='08'||$cabecera["MOTIVO_TRASLADO"]=='09'||$cabecera["MOTIVO_TRASLADO"]=='13'){
        $xmlCPE = $xmlCPE .'<cbc:Information>' . $cabecera["MOTIVO_TRASLADO"] . '</cbc:Information>';
}

$xmlCPE = $xmlCPE .'<cbc:GrossWeightMeasure unitCode="KGM">' . $cabecera["PESO"] . '</cbc:GrossWeightMeasure>
<cbc:TotalTransportHandlingUnitQuantity>' . $cabecera["NUMERO_PAQUETES"] . '</cbc:TotalTransportHandlingUnitQuantity>';


if($cabecera["transbordo"]=='SI'){
    $xmlCPE = $xmlCPE .'<cbc:SpecialInstructions>SUNAT_Envio_IndicadorTransbordoProgramado</cbc:SpecialInstructions>';
}
if($cabecera["vehiculo_m1l"]=='SI'){
    $xmlCPE = $xmlCPE .'<cbc:SpecialInstructions>SUNAT_Envio_IndicadorTrasladoVehiculoM1L</cbc:SpecialInstructions>';
} 

$xmlCPE = $xmlCPE .'<cac:ShipmentStage>
			<cbc:TransportModeCode>' . $cabecera["CODTIPO_TRANSPORTISTA"] . '</cbc:TransportModeCode>
			<cac:TransitPeriod>
				<cbc:StartDate>' . $cabecera["FECHA_TRANSPORTE"] . '</cbc:StartDate>
			</cac:TransitPeriod>';
			
if($cabecera["CODTIPO_TRANSPORTISTA"]=='01'){
    
$xmlCPE = $xmlCPE .'
<cac:CarrierParty>
<cac:PartyIdentification>
<cbc:ID schemeID="' . $cabecera["TIPO_DOCUMENTO_TRANSPORTE"] . '">' . $cabecera["NRO_DOCUMENTO_TRANSPORTE"] . '</cbc:ID>
</cac:PartyIdentification>
<cac:PartyLegalEntity>
<cbc:RegistrationName><![CDATA[' . ValidarCaracteresInv($cabecera["RAZON_SOCIAL_TRANSPORTE"]) . ']]></cbc:RegistrationName>
</cac:PartyLegalEntity>
</cac:CarrierParty>
';

}

$xmlCPE = $xmlCPE .'<cac:TransportMeans>
                                <cac:RoadTransport>
                                    <cbc:LicensePlateID>' . $cabecera["PLACA_VEHICULO"] . '</cbc:LicensePlateID>
                                </cac:RoadTransport>
                            </cac:TransportMeans>
                            
<!-- CONDUCTOR PRINCIPAL -->                         
<cac:DriverPerson>
<cbc:ID schemeID="' . $cabecera["COD_TIPO_DOC_CHOFER"] . '">' . $cabecera["NRO_DOC_CHOFER"] . '</cbc:ID>
<cbc:FirstName>' . $cabecera["chofer_nombre"] . '</cbc:FirstName>
<cbc:FamilyName>' . $cabecera["chofer_apellido"] . '</cbc:FamilyName>
<cbc:JobTitle>Principal</cbc:JobTitle>
<cac:IdentityDocumentReference>
<cbc:ID>' . $cabecera["chofer_lisencia"] . '</cbc:ID>
</cac:IdentityDocumentReference>
</cac:DriverPerson>';

if($cabecera["COD_TIPO_DOC_CHOFER2"]!=''){

$xmlCPE = $xmlCPE .'

<cac:DriverPerson>
<cbc:ID schemeID="' . $cabecera["COD_TIPO_DOC_CHOFER2"] . '">' . $cabecera["NRO_DOC_CHOFER2"] . '</cbc:ID>
<cbc:FirstName>' . $cabecera["chofer_nombre2"] . '</cbc:FirstName>
<cbc:FamilyName>' . $cabecera["chofer_apellido2"] . '</cbc:FamilyName>
<cbc:JobTitle>Secundario</cbc:JobTitle>
<cac:IdentityDocumentReference>
<cbc:ID>' . $cabecera["chofer_lisencia2"] . '</cbc:ID>
</cac:IdentityDocumentReference>
</cac:DriverPerson>
';

}

$xmlCPE = $xmlCPE .'</cac:ShipmentStage>';
		

$xmlCPE = $xmlCPE .'
<cac:Delivery>
<cac:DeliveryAddress>
<cbc:ID schemeName="Ubigeos" schemeAgencyName="PE:INEI">' . $cabecera["UBIGEO_DESTINO"] . '</cbc:ID>';
if($cabecera["CODMOTIVO_TRASLADO"]=='04'){
$xmlCPE = $xmlCPE .'<cbc:AddressTypeCode listID="' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '" listAgencyName="PE:SUNAT" listName="Establecimientos anexos">00</cbc:AddressTypeCode>';
}
$xmlCPE = $xmlCPE .'<cac:AddressLine>
<cbc:Line><![CDATA[' . ValidarCaracteresInv($cabecera["DIR_DESTINO"]).']]></cbc:Line>
</cac:AddressLine>
</cac:DeliveryAddress>
		
<cac:Despatch>
<cac:DespatchAddress>
<cbc:ID schemeName="Ubigeos" schemeAgencyName="PE:INEI">' . $cabecera["UBIGEO_PARTIDA"] . '</cbc:ID>';
if($cabecera["CODMOTIVO_TRASLADO"]=='04'){
$xmlCPE = $xmlCPE .'<cbc:AddressTypeCode listID="' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '" listAgencyName="PE:SUNAT" listName="Establecimientos anexos">00</cbc:AddressTypeCode>';
}
$xmlCPE = $xmlCPE .'<cac:AddressLine>
<cbc:Line><![CDATA[' . $cabecera["DIR_PARTIDA"] . ']]></cbc:Line>
</cac:AddressLine>
</cac:DespatchAddress>';

if($cabecera["NRO_DOCUMENTO_REMITENTE"]<>''){
$xmlCPE = $xmlCPE . '
<!-- DATOS DEL REMITENTE -->
<cac:DespatchParty>
<cac:PartyIdentification>
<cbc:ID schemeID="6" schemeName="Documento de Identidad" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06">' .$cabecera["NRO_DOCUMENTO_REMITENTE"]. '</cbc:ID>
</cac:PartyIdentification>
<cac:PartyLegalEntity>
<cbc:RegistrationName><![CDATA[' .ValidarCaracteresInv($cabecera["RAZON_SOCIAL_REMITENTE"]). ']]></cbc:RegistrationName>
</cac:PartyLegalEntity>
</cac:DespatchParty>
<!-- DATOS DEL REMITENTE -->';
}

$xmlCPE = $xmlCPE . '</cac:Despatch>
</cac:Delivery>';
		
$xmlCPE = $xmlCPE . '
<cac:TransportHandlingUnit>
<cbc:ID>-</cbc:ID>
<cac:TransportEquipment>
<cbc:ID>' . $cabecera["PLACA_VEHICULO"] . '</cbc:ID>
';

if($cabecera["TARJETA_CIRCULACION"]!=''){
$xmlCPE = $xmlCPE.'
<cac:ApplicableTransportMeans>
<cbc:RegistrationNationalityID>'.$cabecera["TARJETA_CIRCULACION"].'</cbc:RegistrationNationalityID>
</cac:ApplicableTransportMeans>
';
}

if($cabecera["PERMISO_CIRCULACION"]!=''){
$xmlCPE = $xmlCPE . '
<cac:ShipmentDocumentReference>
<cbc:ID schemeID="06" schemeName="Entidad Autorizadora" schemeAgencyName="PE:SUNAT" schemeURI="urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogoD37">
' . $cabecera["PERMISO_CIRCULACION"] . '
</cbc:ID>
</cac:ShipmentDocumentReference>';
}

$xmlCPE = $xmlCPE . '
</cac:TransportEquipment>
</cac:TransportHandlingUnit>
';
		
	

/*
if ($cabecera["PLACA_CARRETA"] <> "") {
$xmlCPE = $xmlCPE . '<cac:TransportHandlingUnit>
                                <cbc:ID>' . $cabecera["PLACA_VEHICULO"] . '</cbc:ID>
                                <cac:TransportEquipment>
                                    <cbc:ID>' . $cabecera["PLACA_CARRETA"] . '</cbc:ID>
                                </cac:TransportEquipment>
                            </cac:TransportHandlingUnit>';
}
*/
	
$xmlCPE = $xmlCPE . '<cac:OriginAddress>
<cbc:ID>' . $cabecera["UBIGEO_PARTIDA"] . '</cbc:ID>';

if($cabecera["CODMOTIVO_TRASLADO"]=='04'){
$xmlCPE = $xmlCPE .'<cbc:AddressTypeCode listID="' . $cabecera["NRO_DOCUMENTO_EMPRESA"] . '" listAgencyName="PE:SUNAT" listName="Establecimientos anexos">00</cbc:AddressTypeCode>';
}

$xmlCPE = $xmlCPE .'<cbc:StreetName><![CDATA[' . ValidarCaracteresInv($cabecera["DIR_PARTIDA"]) . ']]></cbc:StreetName>
</cac:OriginAddress>
    </cac:Shipment>';

for ($i = 0; $i < count($detalle); $i++) {
        $xmlCPE = $xmlCPE . '<cac:DespatchLine>
        <cbc:ID>' . $detalle[$i]["ITEM"] . '</cbc:ID>
<cbc:DeliveredQuantity unitCode="NIU">' . $detalle[$i]["PESO"] . '</cbc:DeliveredQuantity>
<cac:OrderLineReference>
<cbc:LineID>' . $detalle[$i]["NUMERO_ORDEN"] . '</cbc:LineID>
</cac:OrderLineReference>

<cac:Item>
<cbc:Description><![CDATA[' . ValidarCaracteresInv($detalle[$i]["DESCRIPCION"]) . ']]></cbc:Description>
			<cac:SellersItemIdentification>
				<cbc:ID>' . ValidarCaracteresInv($detalle[$i]["CODIGO_PRODUCTO"]) . '</cbc:ID>
			</cac:SellersItemIdentification>
		</cac:Item>
    </cac:DespatchLine>';
    }
$xmlCPE = $xmlCPE . '</DespatchAdvice>';

    $doc->loadXML($xmlCPE);
    $doc->save(dirname(__FILE__) . '/' . $ruta . '.XML');

    //return 'XML GUIA CREADO';
}


?>
